newine_client
=============

Dispenser software

# Dependencies
## libnfc
This needs to be compiled from source on the BBB: https://github.com/nfc-tools/libnfc
`sudo apt-get install libnfc-dev` works on some platforms. 

## libcurl
`sudo apt-get install libcurl-dev` will show possible packages. `sudo apt-get install libcurl4-openssl-dev` is usually available and works fine.

## libjansson
`sudo apt-get install libjansson-dev` might install old versions. We need >= 2.5. The version can be checked with `cat /usr/include/jansson.h | grep JANSSON_VERSION`. If the installed version is too old, remove with `sudo apt-get remove libjansson-dev`, and compile from source: http://www.digip.org/jansson/
