require 'sinatra'
require 'json'


class NewineConfigurationServer < Sinatra::Application

	configure do
		set :pipe_file, open('newine_conf_fifo','w+')
	end
	post '/' do	
		settings.pipe_file.puts request.body.read
		settings.pipe_file.flush
		'OK'
	end
end
