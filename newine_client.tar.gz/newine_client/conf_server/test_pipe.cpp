#include <iostream>
#include <fstream>
using namespace std;
int main(void)
{

	ifstream f("newine_conf_fifo",ios_base::in);
	while(1)
	{
		string val;
		
		cout << "Waiting" << endl;
		getline(f,val);
		
		cout << val << endl;
		
		
	}

}
