#ifndef CYC_TESTING_HPP
#define CYC_TESTING_HPP

#include "io_shield.hpp"
#include "lcd_array.hpp"
#include "tested_station.hpp"
#include <vector>
#include <string>
#include <atomic>

class CycTesting
{
public:
    CycTesting(int bottles, IOShield *io_board, LCDArray *lcd_array);

    void test_press(int target_tests, std::atomic<bool> *stop = NULL);
    void reset_recorded_data(void);

private:
    std::vector<TestedStation> stations;

    std::atomic<bool> *stop;

    bool is_testing_done(int target_tests);

    std::string records_filename;

    void save_testing_data(void);
    bool load_recorded_data(void);
    bool file_exists(const std::string &filename);

    IOShield *io_board;
    LCDArray *lcd_array;

    void show_stations_data(void);
    void perform_parallel_test(void);
    bool current_test_done(void);
};

#endif