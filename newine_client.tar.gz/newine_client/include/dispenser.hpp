// dispenser.hpp

#ifndef DISPENSER_HPP
#define DISPENSER_HPP

#include <string>
#include <iostream>
#include <fstream>
#include <thread>
#include <atomic>
#include <functional>
#include <utility>
#include <math.h>

#include "phy_config.hpp"
#include "nfc_reader.hpp"
#include "newine_api_client.hpp"
#include "newine_api_user.hpp"
#include "io_board.hpp"
#include "io_shield.hpp"
#include "touch_button_array.hpp"
#include "lcd_array.hpp"
#include "dispenser_configuration.hpp"
#include "relay.hpp"
#include "wine_server.hpp"
#include "temp_sensor.hpp"
#include "nitro_sensor.hpp"
#include "cyc_testing.hpp"

#define USER_INPUT_TIMEOUT		9 	//in seconds
#define DISPENSER_PING_TIMEOUT	60 	//in seconds
#define TO_BCD(val) ((((unsigned char)((val)/10))<<4) | (unsigned char)(((unsigned char)(val))%10))

#define CLEANING_VOLUME 150
#define PUCHITOU_VOLUME 10

class Dispenser;
typedef enum
{
    INITIALIZING,
    IDLE,
    CONFIGURING,
    AUTHENTICATING,
    AWAITING_SELECTION,
    SERVING,
    CLEANING,
    SHOWING_INFO,
    SHOWING_PRESS_CONTROLS,
    SHOWING_FLOWMETER_ADJUST,
    SHOWING_SERVING_ADJUST,
    DETACHING_AND_LOADING,
    PRESS_TESTING,
    SHUTTING_DOWN,
    SELECTING_WINE,
    MAX_DISPENSER_STATE
   
} DispenserStateID;

typedef DispenserStateID (Dispenser::*DispenserStateTransition)(void);

class Dispenser
{
    private:
		NewineAPIUser * current_user;
		bool superUserMode;

        DispenserConfiguration configuration;

        NewineAPIClient nw_api;

        std::mutex lock;
        std::condition_variable event_notifier;

        IOShield io_board;
        NFCReader nfc_board;

        WineServer wine_server;

        TemperatureSensor temp_sensor;
        NitroSensor nitro_sensor;

        CycTesting cyc_testing;

        LCDArray lcd_array;

        TouchButtonArray serving_buttons[N_BOTTLES];

        Relay power_relay;

        std::string uid;
        int id;
        DispenserStateID current_state;
        DispenserStateID previous_state;
        DispenserStateTransition state_transitions[MAX_DISPENSER_STATE];
        std::atomic<bool> * shutdown;

        std::atomic<bool> * button_pressed;

        unsigned int selected_bottle;
        unsigned int selected_serving;

        DispenserStateID initialize(void);
        DispenserStateID idle(void);
        DispenserStateID configure(void);
        DispenserStateID authenticate(void);
        DispenserStateID await_selection(void);
        DispenserStateID serve(void);
        DispenserStateID clean(void);
        DispenserStateID show_info(void);
        DispenserStateID show_press_controls(void);
        DispenserStateID show_flowmeter_adjust(void);
        DispenserStateID show_serving_adjust(void);
        DispenserStateID detach_and_load(void);
        DispenserStateID test_press(void);
        DispenserStateID shut_down(void);
        DispenserStateID select_wine(void);

        void show_inactive_stations(void);

        void wait_for_wakeup_signal(std::function<bool (void)> test);
        bool wait_for_wakeup_signal(std::chrono::milliseconds timeout, std::function<bool (void)> test);

        void reset_buttons_notifications(void);

        bool update_idle_displays;

    public:

        Dispenser(void);
        void run(void);
        void stop(void);
        std::string get_uid(void);
};

#endif
