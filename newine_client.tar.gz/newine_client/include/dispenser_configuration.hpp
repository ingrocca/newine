
#ifndef DISPENSER_CONFIGURATION_HPP
#define DISPENSER_CONFIGURATION_HPP

#include <condition_variable>
#include <thread>
#include <string>
#include <atomic>


struct Serving
{
    double price;
    int volume;
};

#define configuration_file_name  "/home/newine/newine_client/configuration.json"

class DispenserConfiguration
{
	public:
		DispenserConfiguration(unsigned int n_tmps, unsigned int n_bttles, unsigned int n_srving_sizes, std::condition_variable * ev_not);
		~DispenserConfiguration(void);
		void load(const char * fname);
		void save(const char * fname);

		bool changed(void);
		void flag_down(void);

		double * temperature; // Fake data pulled from the config file

		unsigned long int * product_ids;

		Serving ** serving_options;
		int * remaining_volumes;
		std::string * wine_names;
		std::string * wine_details;

		std::atomic<bool> * shutdown_rqst;

    private:
        unsigned int n_serving_sizes;
        unsigned int n_bottles;
        unsigned int n_temps;

        std::thread * listener;
        std::atomic<bool> * shutdown;
        std::atomic<bool> * change;

        void listener_task(void);

        std::condition_variable * ev_notifier;
};

#endif