// io_board.hpp
// SPI GPIO expander driver

#ifndef IO_BOARD_HPP
#define IO_BOARD_HPP

#include "spi.hpp"

#include <iostream>
#include <cstdio>
#include <sys/ioctl.h>
#include <thread>
#include <atomic>
#include <mutex>

class IOBoard
{
    // spidev file
    private:
        unsigned int bank_size;

        int spi_bus;
        int spi_chan;
        int speed;
        SPI spi;

        std::mutex lock;

        // buffer representing shift register outputs
        unsigned char  * outputs;
        // buffer representing shift register inputs
        unsigned char  * inputs;

        int length;

        void perform_transfer(void);

    public:
        // Constructor that receives the SPI device bus and CS number
        IOBoard(int bus, int chan, int bank_size, int spd);

        void initialize(void);
        void stop(void);

        void lock_updates(void);
        void unlock_updates(void);

        unsigned char get(int position);
        unsigned char non_blocking_get(int position);
        unsigned char async_get(int position); // This does not cause a new SPI transfer! It simply uses the last read values

        void set(unsigned char value, unsigned char mask, int position);
        void set(unsigned char *value, unsigned char *mask, int position, int n_bytes);
        void non_blocking_set(unsigned char *value, unsigned char *mask, int position, int n_bytes);
};

#endif