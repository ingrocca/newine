#ifndef IOSHIELD_HPP_INCLUDED
#define IOSHIELD_HPP_INCLUDED

#include <bitset>
#include "io_board.hpp"

//Inputs
#define TS3 3
#define TS2 2
#define TS1 1
#define TS0 0

//Outputs
#define L1  15
#define L2  14
#define L3  13
#define L4  8
#define SC  12
#define DI  11
#define DB0 10
#define DB1 9
#define DB2 7
#define DB3 6
#define DB4 5
#define DB5 4
#define DB6 3
#define DB7 2
#define CS1 1
#define CS0 0

const char led[5] = {L1, L2, L3, L4, L1|L2|L3|L4};
const char display_cs[2] = {CS0, CS1};

#define LIMIT_SWITCH_A_MASK (1 << 3)
#define LIMIT_SWITCH_B_MASK (1 << 4)
#define FLOWMETER_MASK (1 << 5)

// The limit switch is active low, so we negate it first
// There are two independent limit switches, and we only require one of them to be pressed to consider the press closed
#define LIMIT_SWITCH_STATUS(data) (!(((~data) & (LIMIT_SWITCH_A_MASK | LIMIT_SWITCH_B_MASK)) == 0x00))

#define FLOWMETER_STATUS(data) (((data) & FLOWMETER_MASK) != 0x00)

//typedef enum {none, button0, button1, button2, button3, error}touch_sensor;

class IOShield : public IOBoard
{
    private:
        // buffer representing shift register outputs
        std::bitset<16> *out;
        unsigned int total_shields;

    public:
        typedef enum
        {
            STOP,
            FORWARD,
            BACKWARD
        } MotorDirection;

        typedef enum
        {
            STUCK,
            UPWARD,
            DOWNWARD
        } PistonDirection;

        IOShield(int bus, int chan, int n_shields, int spd);
        void initialize(void);
        void stop(void);

        //Inputs management functions
//      touch_sensor get_touch sensor(unsigned char shield);

        //Outputs management functions
        void set_led(unsigned char shield, unsigned char i);
        void clear_led(unsigned char shield, unsigned char i);

        void set_press_motor(unsigned char shield, MotorDirection direction);
        void set_bottle_piston(unsigned char shield, PistonDirection direction);

        void set_display_data(unsigned char shield, char data);
        void set_display_cs(unsigned char shield, unsigned char i);
        void clear_display_cs(unsigned char shield, unsigned char i);
        void set_display_di(unsigned char shield);
        void clear_display_di(unsigned char shield);
        void flush(void);
        void non_blocking_flush(void);
};

#endif // IOSHIELD_HPP_INCLUDED
