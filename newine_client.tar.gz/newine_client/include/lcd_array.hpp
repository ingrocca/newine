#ifndef LCDARRAY_HPP
#define LCDARRAY_HPP

#include "lcdisplay.hpp"
#include "io_shield.hpp"
#include "phy_config.hpp"
#include "winstar_wg12864a.hpp"
#include <vector>

#include <thread>
#include <string>
#include <mutex>
#include <atomic>

class LCDArray
{
    public:
        void initialize(IOShield *board);
        ~LCDArray(void);

        LCDisplay displays[N_BOTTLES];
        std::mutex draw_lock; // Must be locked before calling any functions that change an LCD's memory

        std::atomic<bool> *updated;
        void wait_for_update(void);

    private:
        IOShield *board;

        std::atomic<bool> *shutdown;

        std::thread *updater;
        void update_task(void);

        int on_counter;

        void mass_execute_instruction(char instr_data);
        void mass_turn_on(void);
        void mass_set_start_line(char address);
        void mass_set_page(char x_address);
        void mass_set_y_address(char y_address);
        void mass_set_display_cs(unsigned char i);
        void mass_clear_display_cs(unsigned char i);
        void mass_write_data(int y, int page);
};

#endif