#ifndef LCDISPLAY_HPP
#define LCDISPLAY_HPP

#include "io_shield.hpp"
#include "winstar_wg12864a.hpp"
#include "dispenser_configuration.hpp"

#define CLEAN_CONFIRM_OK 0
#define CLEAN_CONFIRM_CANCEL 1

enum class PressMenu {
    OPEN = 0,
    CLOSE = 1,
    EXIT = 2
};

enum class TechPanelMenu {
    FLOWMETER_ADJUST = 0,
    SERVING_ADJUST = 1,
    PRESS_CONTROLS = 2
};

enum class TestingPanelMenu {
    TEST_PRESS = 0,
    RESET_TEST_DATA = 1,
};

enum class FlowAdjust {
    BIG_SERVING = 0,
    RESET_CALIB = 1,
    EXIT = 2
};

enum class FlowAdjustQuery {
    SERVED_MORE = 0,
    SERVED_LESS = 1,
    EXIT = 2
};

enum class ServeAdjust {
    SMALL_SERVING = 0,
    RESET_OFFSET = 1,
    EXIT = 2
};

enum class ServeAdjustQuery {
    SERVED_MORE = 0,
    SERVED_LESS = 1,
    EXIT = 2
};

class LCDisplay
{
    private:
        void write_string(std::string s);
        void show_wine(void);
        void show_price_min(unsigned int p, bool b=true);
        void show_price_med(unsigned int p, bool b=true);
        void show_price_max(unsigned int p, bool b=true);
        void show_wine_numbers(bool first = true, bool second = true, bool third = true);
        void clear_wine_numbers(void);
        void show_list_controls(void);

        std::string wine_name;
        std::string wine_vintage;

        Serving wine_serving[3];
        int remaining_volume;
        int temperature;
        bool nitro_ok;

        static const unsigned char logo[];

    public:
        Winstar_WG12864A graphic;
        void initialize(IOShield * brd, unsigned int ind, bool turn_on);
        void reset();
        void clear(void);
        void show_init(void);
        void show_idle(bool uSU=false);
        void show_serving(void);
        void show_authorized_client(int user_credit, int remaining_volume, bool uSU=false);
        void show_authorized_admin(bool can_clean, bool can_detach);
        void show_tech_panel(void);
        void show_testing_panel(void);
        void show_unauthorized(void);
        void show_cleaning(void);
        void show_cleaning_confirmation(void);
        void update_wine(std::string name, std::string vintage, Serving *prices, int remaining_volume);
        void show_message(std::string msg);
        void show_bitmap(const unsigned char *bitmap, bool inverted);
        void update_temp(int t);
        void show_temp_and_nitro(void);
        void show_detaching(void);
        void show_attaching(void);
        void show_replaced(void);
        void show_changed(void);
        void show_changing_bottle(void);
        void show_info(int bottle_uptime, int clean_uptime);
        void show_press_controls(void);
        void show_flowmeter_adjust(void);
        void show_flowmeter_adjust_query(int served_volume, bool serve_successsful = true);
        void show_flowmeter_adjust_controls(int served_volume, int actual_measure, bool serve_successsful = true);
        void show_serving_adjust(void);
        void show_serving_adjust_query(int attempted_volume, bool serve_successsful = true);
        void show_instructions(std::string line0, std::string line1, std::string line2);
        void show_inactive_station(void);
        void update_volume(int rem_vol);
        void update_nitro(bool nitro_ok);
        void show_wine_list(std::string wine_list_names, std::string wine_list_details);

        void show_testing_data(int tests_performed, bool limit_switch_working, bool leak_found);
};

#endif
