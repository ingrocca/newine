// newine_api_client.hpp

#ifndef NEWINE_API_CLIENT_HPP
#define NEWINE_API_CLIENT_HPP

#include <string>
#include <iostream>
#include "restclient.hpp"
#include "newine_api_user.hpp"
#include "newine_api_serving.hpp"



const std::string api_server_url = "192.168.0.1:3000";
const std::string api_users_route = "/users/tags";
const std::string api_servings_route = "/servings";
const std::string api_register_route = "/dispensers/register";
const std::string api_ping_route = "/dispensers/ping";
const std::string api_temperature_route = "/dispensers/temperature";
const std::string api_wine_list_route = "/wines";
const std::string api_wine_selection_route = "/dispensers/bottle_holders/wine/0.json";



class NewineAPIClient
{
    public:
        int register_with_server(std::string uid);
        bool ping_to_server(int id);
        void wine_list_get(int * list_size, int wine_id[], std::string wine_list_names[], std::string wine_list_details[]);
		void wine_list_post(int wine_id, int bottle_index, int disp_id);
		int wine_taste_post(int bottle_index, int disp_id);
		int wine_replace_post(int bottle_index, int disp_id);
        int wine_days(int bottle_index, int disp_id);
        NewineAPIUser * users_get(std::string user_id);
        NewineAPIServing * servings_post(NewineAPIServing * serving_in);
        bool temperature_post(int ctrl_nr,double temp, int disp_id);

};

#endif
