
#ifndef NEWINE_API_SERVING_HPP
#define NEWINE_API_SERVING_HPP

#include <string>
#include <jansson.h>
#ifndef JSON_INTEGER_IS_LONG_LONG
    #define JSON_INTEGER_IS_LONG_LONG 1
#endif

class NewineAPIServing
{
    public:
        int dispenser_id;
        std::string uid;
        int bottle_index;
        int serving_index;
        double price;
        int volume;
        double remaining_credit;
        bool valid_serving;

        NewineAPIServing(json_t * serv);
        NewineAPIServing(int dispenser_id_in, std::string uid_in, int bottle_index_in, int serving_index_in, double price_in, int volume_in, double credit);
        json_t * to_json_object(void);
        std::string to_json(void);
};


#endif