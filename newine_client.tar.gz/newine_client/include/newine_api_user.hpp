
#ifndef NEWINE_API_USER_HPP
#define NEWINE_API_USER_HPP

#include <string>
#include <jansson.h>
#ifndef JSON_INTEGER_IS_LONG_LONG
    #define JSON_INTEGER_IS_LONG_LONG 1
#endif

enum class UserType {
    REGULAR,
    TECH_USER,
    TESTING_USER,
};

class NewineAPIUser
{
    public:
        long long id;
        std::string uid;
        std::string name;

        double credit;
        bool can_clean;
        bool can_detach;
        bool can_set_temp;
        bool valid_user;

        UserType type;

        NewineAPIUser(json_t * usr);
};


#endif