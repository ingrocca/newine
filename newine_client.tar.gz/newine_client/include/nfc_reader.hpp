// nfc_reader.hpp

#ifndef NFC_READER_HPP
#define NFC_READER_HPP

#include <string>
#include <thread>
#include <condition_variable>
#include <atomic>
#include <mutex>
#include <iostream>
#include <nfc/nfc.h>
#include "relay.hpp"

#define NFC_REFRESH_TIME    50//in miliseconds

//Modulation type & baud rate configuration
const nfc_modulation nmMifare = {NMT_ISO14443A, NBR_106};

class NFCReader
{
    private:
        std::atomic<bool> * shutdown;
        std::thread * listener;
        std::mutex lock;
        std::condition_variable *event_notifier;

        bool hardware_initialized;
        int init_attempts;
        void reset_nfc(void);

        bool card_presence;
        std::string card_data;
        std::string * uid;

        void card_listener(void);

        nfc_context *context;
        nfc_device *pnd;
        nfc_target nt;

        Relay nfc_reset_pin;

    public:
        void initialize(std::condition_variable *event_not);
        bool setup_hardware(void);
        void stop(void);
        bool card_present(void);
        void flag_down(void);
        std::string get_user_id(void);
};

#endif