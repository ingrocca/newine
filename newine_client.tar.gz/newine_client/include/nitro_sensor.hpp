#ifndef NITRO_SENSOR_HPP
#define NITRO_SENSOR_HPP

#include "sensor.hpp"
#include <string>

class NitroSensor : public Sensor<bool> {
public:
    NitroSensor(std::string adc, int threshold);
    bool update_value(void);
    void recharge(void);
    bool get_value(void);
    
private:
    std::string adc;
    int threshold;
    bool above_mark;
    bool recharged;
    int samples[5];
    int n_samples;
    int average;
};

#endif