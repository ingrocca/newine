#ifndef RELAY_HPP
#define RELAY_HPP

#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <stdlib.h>

class Relay
{
    private:
        std::string gpio;

    public:
        void initialize(std::string relay_gpio);
        void stop(void);
        void turn_on();
        void turn_off();
};

#endif