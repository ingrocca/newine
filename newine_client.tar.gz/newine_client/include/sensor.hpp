#ifndef SENSOR_HPP
#define SENSOR_HPP

#include <mutex>
#include <thread>
#include <atomic>

#define SENSOR_SLEEP_TIME_MS (5000)

template <class T> class Sensor {
public:
    void start(void) {
        updated = false;
        shutdown = false;

        this->thread = new std::thread([this](){
            this->sensor_thread();
        });
    }

    void stop(void) {
        shutdown = true;

        thread->join();
        delete thread;
    }

    bool read(T *new_value) {
        mutex.lock();

        if (updated) {
            *new_value = this->value;
            mutex.unlock();
            return true;
        } else {
            mutex.unlock();
            return false;
        }
    }

protected:
    virtual bool update_value(void) = 0;
    T value;

private:
    bool updated;

    std::mutex mutex;
    std::thread *thread;
    std::atomic<bool> shutdown;

    void sensor_thread(void) {
        while (!shutdown) {
            mutex.lock();

            if (update_value())
            {
                updated = true;
            }

            mutex.unlock();

            std::this_thread::sleep_for(std::chrono::milliseconds(SENSOR_SLEEP_TIME_MS));
        }
    }
};

#endif