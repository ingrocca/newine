#ifndef TEMP_SENSOR_HPP
#define TEMP_SENSOR_HPP

#include "sensor.hpp"
#include <string>
#include <vector>

class TemperatureSensor : public Sensor<int> {
public:
    TemperatureSensor(void);

protected:
    bool update_value(void);

private:
    bool get_sensor_filename(void);
    bool getdir(std::string dir, std::vector<std::string> &files);
    std::string sensor_filename;
};

#endif