#ifndef TESTED_STATION_HPP
#define TESTED_STATION_HPP

#include <jansson.h>
#include "lcdisplay.hpp"
#include "io_shield.hpp"
#include <vector>
#include <string>

class TestedStation
{
public:
    TestedStation(int station_index, int n_stations);

    bool should_perform_new_test(int target_tests);
    void show_testing_data(LCDisplay *lcd_display);

    void start_new_test(IOShield *io_board);
    bool current_test_done(void);

    // Because the testing is carried out in two separate steps (after and before the SPI transfer),
    // the acting on the motor and the reading of the sensors occur on two different places, which
    // leads us to having intermidiate states.
    void test_first_step(void);
    void test_second_step(void);

    void load(json_t *j_val);
    void save(json_t *j_val);

private:
    bool is_faulty(void);
    bool detect_limit_switch_fault(bool limit_switch);
    bool detect_leak(bool flowmeter);

    long open_cmd_time;
    long halt_open_cmd_time;
    long close_cmd_time;
    long halt_close_cmd_time;

    long get_time_ms(void);

    int station_index;
    int n_stations;

    bool limit_switch_working;
    bool leak_found;
    int tests_performed;

    typedef enum
    {
        CLOSED, // We're ready to start a new test, but haven't yet opened the press
        CLOSED_DONE, // We are ready to open the press
        OPENING, // The motor is moving backward
        OPENING_DONE, // We have finished opening the hose, and should halt the motor
        OPEN, // The motor is halted, but the press is open
        OPEN_DONE, // The press has been open for enough time and should now be closed
        CLOSING, // The motor is moving forward. As soon as the press closes the test will end
        CLOSING_DONE, // We have finished closing the hose, and should halt the motor
        DONE // We're not in a test, the motor is halted. The press might not be closed, if we detected a fault in the last test
    } TestStatus;
    TestStatus test_status;

    bool suspect_faulty_limit_switch;

    bool initial_flowmeter_status;
    bool previous_flowmeter_status;
    long last_pulse_time;

    IOShield *board_under_test;
};

#endif