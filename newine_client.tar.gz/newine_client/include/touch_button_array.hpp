
#ifndef TOUCH_BUTTON_ARRAY_HPP
#define TOUCH_BUTTON_ARRAY_HPP

#include "io_board.hpp"
#include <condition_variable>

#define BUTTONS_REFRESH_TIME			10	//in miliseconds
#define BUTTONS_TIMEOUT 				100//in miliseconds (will be rounded to the closest lower multiple of BUTTONS_REFRESH_TIME)
#define BUTTONS_SLIDE_TIMEOUT			1000//in miliseconds - Time to test the gesture of sliding
#define BUTTONS_ALL_PRESSED_TIMEOUT		2000//in miliseconds - Time to test the gesture of keeping all buttons pressed for a long time
#define BUTTONS_ALL_HOLD_TIMEOUT		5000//in miliseconds - Time to test the gesture of keeping all buttons pressed for a very long time
#define BUTTONS_MAX_ITER				(BUTTONS_TIMEOUT/BUTTONS_REFRESH_TIME)
#define BUTTONS_SLIDE_MAX_ITER			(BUTTONS_SLIDE_TIMEOUT/BUTTONS_REFRESH_TIME)
#define BUTTONS_ALL_PRESSED_MAX_ITER	(BUTTONS_ALL_PRESSED_TIMEOUT/BUTTONS_REFRESH_TIME)
#define BUTTONS_ALL_HOLD_MAX_ITER		(BUTTONS_ALL_HOLD_TIMEOUT/BUTTONS_REFRESH_TIME)

#define NO_BUTTON_PRESSED	10
#define ALL_BUTTON_PRESSED	11

class TouchButtonArray;

typedef enum
{
    TOUCH_IDLE,
    SLIDE_LEFT,
    SLIDE_RIGHT,
    BUTTON_PRESSED,
    ALL_PRESSED,
    ALL_HOLD,
    ALL_PRESSED_RELEASED,
    MAX_TOUCH_STATE
}TouchState;

typedef struct
{
    TouchState state;
    unsigned char button;
}TouchEvent;

typedef TouchState (TouchButtonArray::*TouchStateTransition)(unsigned char);


class TouchButtonArray
{
    private:
        IOBoard * board;
        unsigned int board_offset;
        unsigned int n_buttons;

        std::atomic<bool> * pressed;
        std::condition_variable *event_notifier;
        TouchEvent touch_event;
        TouchState touch_state;
        unsigned char last_input;
        unsigned int n_iter;

        bool negative_logic;

        std::thread * listener;
        std::atomic<bool> * shutdown;
        std::mutex lock;

        TouchState t_idle(unsigned char pressed_button);
        TouchState t_button_pressed(unsigned char pressed_button);
        TouchState t_slide_right(unsigned char pressed_button);
        TouchState t_slide_left(unsigned char pressed_button);
        TouchState t_all_pressed(unsigned char pressed_button);

        TouchStateTransition t_state_transitions[MAX_TOUCH_STATE];
        TouchState current_state;
        TouchState previous_state;
        int get_offset;

    public:
        void initialize(IOBoard * brd,unsigned int brd_offst,unsigned int n_bttns, std::atomic<bool> * pressd, std::condition_variable *event_not, bool neg_logic, int get_offset);
        void stop(void);
        void listener_task(void);
        TouchEvent get_event(void);
        void clean_event(void);
};

#endif
