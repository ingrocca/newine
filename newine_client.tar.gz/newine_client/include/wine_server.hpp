#ifndef WINE_SERVER_HPP
#define WINE_SERVER_HPP

#include "io_shield.hpp"
#include "wine_server_config.hpp"
#include <utility>
#include <vector>
#include <list>

#define OPENING_TIMEOUT_MS (1500)
#define CLOSING_TIMEOUT_MS (2000)

#define EMERGENCY_CLOSE_TIMEOUT_MS (2200)

#if OPENING_TIMEOUT_MS > CLOSING_TIMEOUT_MS
    #error
#elif OPENING_TIMEOUT_MS > EMERGENCY_CLOSE_TIMEOUT_MS
    #error
#endif

class WineServer
{
public:
    WineServer(int n_bottles, IOShield *io_board);

    // Closes the press (simply calls emergencyClose with the emergency flag closed)
    void initialize_press(int bottle);

    // Attempts to serve a certain volume (in mililiters) on the selected bottle. Returns true on success.
    bool serve_volume(float target_volume, int bottle, float *served = NULL);

    bool serve_time(long time_milliseconds, int bottle, float *served = NULL);

    bool getLimitSwitchStatus(void);

    WineServerConfig config;

private:
    int n_bottles;
    IOShield *io_board;
    std::vector<bool> limit_switch_working;

    bool serve(float target_volume, long time_milliseconds, bool volume_mode, int bottle, float *served);

    typedef enum
    {
        CLOSED, // The motor is stopped, the hose is fully closed, there's no wine flow
        OPENING, // The motor is moving backwards and the hose is gradually opening, the flow measurement is not very accurate
        OPEN, // The motor has stopped and the hose is fully opened. The flow measurement is now accurate
        CLOSING, // The motor is moving fowarad and the hose is gradually closing. There will be some extra wine flow before the hose fully closes
    } ServingStage;

    typedef struct
    {
        float flow; // In mililiters/milisecond
        float volume; // In mililiters
        bool limit_switch;
    } ServeData;

    // This reads info from the dispenser boards, updating last_flowmeter_sample, and querying the limit switch's status.
    // This function must be called at least once before updateServeData is ever called (so that last_flowmeter_sample is initialized).
    void updateLimitSwitchStatus(void);

    typedef enum
    {
        WAITING_FOR_POLARITY_CHANGE,
        SUSPECTING_POLARITY_CHANGE,
        WAITING_FOR_PULSE_TO_END,
        SUSPECTING_PULSE_HAS_ENDED
    } FlowmeterMeasStage;

    // The flow is measured by counting a number of pulses. If a timeout occurs before said pulses are
    // counted, updateServeData returns immediately, returning false.
    // If the limit switch is pressed, updateServeData returns as soon as this condition is noted,
    // leaving the value inside flow and volume invalid (the hose is closed, so there should be no flow anyway).
    bool updateServeData(int timeout_ms);

    void emergencyCloseFromStage(ServingStage currentStage, bool is_emergency = true);

    float updateAverageFlow(std::list<float> &measured_flows, float new_flow);

    long getTimeMS(void);

    std::pair<bool, long> last_flowmeter_sample;
    ServeData serve_data;
    int selected_bottle;

    WineServerConfig::Calibration calibration;
};

#endif