#ifndef WINE_SERVER_CONFIG_HPP
#define WINE_SERVER_CONFIG_HPP
#include <vector>

class WineServerConfig
{
public:
    WineServerConfig(void);

    void load(void); // Called automatically by the constructor
    void save(void);

    typedef struct
    {
        int bottle_index;
        float whole_pulse_volume; // In mililiters
        float control_volume_offset; // In mililiters
    } Calibration;

    Calibration get(int index);


    void set_whole_pulse_volume(int index, int measured, int actual_measure);
    void increase_control_volume_offset(int index);
    void decrease_control_volume_offset(int index);
    void reset_whole_pulse_volume(int index);
    void reset_control_volume_offset(int index);
private:
    std::vector<Calibration> calibrations;
    void set_value_whole_pulse_volume(int index, int measured, int actual_measure);
    void reset_value_whole_pulse_volume(int index);
    void adjust_control_volume_offset(int index, float adjustment);
    void reset_value_control_volume_offset(int index);

};

#endif