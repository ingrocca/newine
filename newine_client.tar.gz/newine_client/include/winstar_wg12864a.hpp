#ifndef WINSTAR_WG12864A_HPP_INCLUDED
#define WINSTAR_WG12864A_HPP_INCLUDED

#include "adafruit_GFX.hpp"
#include "io_shield.hpp"

#define WG12864A_WIDTH  128
#define WG12864A_HEIGHT 64

#define WG12864A_ON               0b00111111
#define WG12864A_OFF              0b00111110
#define WG12864A_START_LINE       0b11000000
#define WG12864A_START_LINE_MASK  0b00111111
#define WG12864A_SET_PAGE         0b10111000
#define WG12864A_SET_PAGE_MASK    0b00000111
#define WG12864A_SET_Y            0b01000000
#define WG12864A_SET_Y_MASK       0b00111111

class Winstar_WG12864A : public Adafruit_GFX
{
  private:
    IOShield * board;
    unsigned int offset;

    //display functions
    void set_start_line(char address);
    void set_page(char x_address);
    void set_y_address(char y_address);
    void write_data(char data); //CAREFULL! write_data is non_blocking.
                                //write_data loops should be globally locked using
                                //IOBoard::lock_updates() and IOBoard::unlock_updates()

  public:
    char fb[WG12864A_WIDTH][WG12864A_HEIGHT/8];
    Winstar_WG12864A(void);
    void initialize(IOShield * brd, unsigned int ind, bool turn_on);

    void turn_on(void);
    void turn_off(void);
    void drawPixel(int16_t x, int16_t y, uint16_t color);

    void update_display(void);
    void clear_display(void);
};



#endif // WINSTAR_WG12864A_HPP_INCLUDED