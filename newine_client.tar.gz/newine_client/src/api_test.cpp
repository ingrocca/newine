
#include "newine_api_client.hpp"
using namespace std;
int main(void)
{
    NewineAPIClient nw_api;

    int id = nw_api.register_with_server("2513BBBK4560");

    cout << "ID: " << id << endl;

    return 0;


}