#include "cyc_testing.hpp"
#include <jansson.h>
#include <sys/stat.h>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <streambuf>

CycTesting::CycTesting(int bottles, IOShield *io_board, LCDArray *lcd_array)
{
    for (int i = 0; i < bottles; ++i)
    {
        stations.push_back(TestedStation(i, bottles));
    }

    this->io_board = io_board;
    this->lcd_array = lcd_array;

    records_filename = "/home/newine/newine_client/cyc_testing.json";
}

void CycTesting::test_press(int target_tests, std::atomic<bool> *stop)
{
    this->stop = stop;
    if (stop != NULL)
    {
        *stop = false;
    }

    if (!load_recorded_data())
    {
        std::cout << "CycTesting: test_limit_switches: failed to read the recorded data, exiting." << std::endl;
        return;
    }

    show_stations_data();

    while (!is_testing_done(target_tests))
    {
        perform_parallel_test();

        save_testing_data();
        show_stations_data();

        if ((stop != NULL) && (*stop))
        {
            std::cout << "Testing cancelled by the user." << std::endl;
            break;
        }
    }

    std::cout << "Testing done, exiting." << std::endl;
}

bool CycTesting::is_testing_done(int target_tests)
{
    // We should test more if at least one station requires further testing (its limit switch is working and testing hasn't finished)
    for (auto &station : stations)
    {
        if (station.should_perform_new_test(target_tests))
        {
            return false;
        }
    }

    return true;
}

void CycTesting::show_stations_data(void)
{
    lcd_array->draw_lock.lock();
    for (int i = 0; i < stations.size(); ++i)
    {
        stations[i].show_testing_data(&(lcd_array->displays[i]));
    }
    lcd_array->draw_lock.unlock();

    lcd_array->wait_for_update();
}

void CycTesting::perform_parallel_test(void)
{
    io_board->lock_updates();

    for (auto &station : stations)
    {
        station.start_new_test(io_board);
    }

    while (!current_test_done())
    {
        for (auto &station : stations)
        {
            station.test_first_step();
        }

        io_board->non_blocking_flush();

        for (auto &station : stations)
        {
            station.test_second_step();
        }
    }

    io_board->unlock_updates();
}

bool CycTesting::current_test_done(void)
{
    for (auto &station : stations)
    {
        if (!station.current_test_done())
        {
            return false;
        }
    }

    return true;
}

void CycTesting::reset_recorded_data(void)
{
    remove(records_filename.c_str());
}

void CycTesting::save_testing_data(void)
{
    json_t *root = json_object();
    json_t *json_arr = json_array();

    json_object_set_new(root, "tests", json_arr);

    for (auto &station : stations)
    {
        json_t *j_val = json_object();
        station.save(j_val);

        json_array_append(json_arr, j_val);
    }

    std::ofstream file(records_filename);
    file << std::string(json_dumps(root, 0));

    json_decref(root);
}

bool CycTesting::load_recorded_data(void)
{
    if (file_exists(records_filename))
    {
        std::ifstream t(records_filename);
        std::string contents((std::istreambuf_iterator<char>(t)),
                     std::istreambuf_iterator<char>());

        json_error_t error;

        json_t *root = json_loads(contents.c_str(), 0, &error);
        if (!root)
        {
            std::cout << "CycTesting: load_recorded_data: on line " << error.line << ": " << error.text << std::endl;
            return false;
        }

        json_t *j_tests;
        json_unpack(root, "{s:o}", "tests", &j_tests);

        size_t idx;
        json_t *val;
        json_array_foreach(j_tests, idx, val)
        {
            if (idx >= stations.size())
            {
                std::cout << "CycTesting: load_recorded_data: expected data for " << stations.size() << " bottles, found more." << std::endl;
                return false;
            }

            stations[idx].load(val);
        }

        json_decref(root);

        return true;
    }
    else
    {
        for (int i = 0; i < stations.size(); ++i)
        {
            stations[i] = TestedStation(i, stations.size());
        }
    }
}

bool CycTesting::file_exists(const std::string &filename)
{
    struct stat buffer;
    return (stat(filename.c_str(), &buffer) == 0);
}