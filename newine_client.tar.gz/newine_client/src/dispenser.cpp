#include "dispenser.hpp"
#include <iomanip>
#include <vector>

#define TEMP_COMPARMENTS 2
#define FIRST_TEMP_COMPARTMENT_BOTTLES 3 // 3 white wine bottles, 5 red wine bottles

#define NITRO_ADC std::string("AIN2")
#define NITRO_THRESHOLD 5   //variation percentage
#define WINE_LIST_MAX_SIZE 100

using namespace std;

Dispenser::Dispenser(void) :
	io_board(1,0,N_BOTTLES, 200000), // 200kHz
	configuration(TEMP_COMPARMENTS, N_BOTTLES, N_SERVING_SIZES, &event_notifier),
    wine_server(N_BOTTLES, &io_board),
    nitro_sensor(NITRO_ADC, NITRO_THRESHOLD),
    cyc_testing(N_BOTTLES, &io_board, &lcd_array)
{
	cout << "Initializing state transitions" << endl;

	state_transitions[INITIALIZING] = &Dispenser::initialize;
	state_transitions[IDLE] = &Dispenser::idle;
	state_transitions[CONFIGURING] = &Dispenser::configure;
	state_transitions[AUTHENTICATING] = &Dispenser::authenticate;
	state_transitions[AWAITING_SELECTION] = &Dispenser::await_selection;
	state_transitions[SERVING] = &Dispenser::serve;
	state_transitions[CLEANING] = &Dispenser::clean;
    state_transitions[SHOWING_INFO] = &Dispenser::show_info;
    state_transitions[SHOWING_PRESS_CONTROLS] = &Dispenser::show_press_controls;
    state_transitions[SHOWING_FLOWMETER_ADJUST] = &Dispenser::show_flowmeter_adjust;
    state_transitions[SHOWING_SERVING_ADJUST] = &Dispenser::show_serving_adjust;
    state_transitions[PRESS_TESTING] = &Dispenser::test_press;
	state_transitions[DETACHING_AND_LOADING] = &Dispenser::detach_and_load;
	state_transitions[SHUTTING_DOWN] = &Dispenser::shut_down;
    state_transitions[SELECTING_WINE] = &Dispenser::select_wine;

	current_state = INITIALIZING;

	cout << "Initializing IPC..." << endl;
	shutdown = new std::atomic<bool>(false);

	button_pressed = new std::atomic<bool>(false);

	superUserMode=false;

	uid = get_uid();
	cout << "UID: " << uid << endl;
	// Open pipes?
}

void Dispenser::run(void)
{
    cout << "Starting state machine." << endl;
    while(!*shutdown)
    {
        previous_state = current_state;
        current_state = (this->*(state_transitions[current_state]))();
    }
}


// State transition methods

DispenserStateID Dispenser::initialize(void)
{
	// TODO dynamic CONF_FILE in member variable

	cout << "Loading configuration" << endl;
	configuration.load(configuration_file_name);

    cout << "Initializing peripheral boards..." << endl;
    io_board.initialize();

    cout << "Initializing relays" << endl;

    // Turn off all relays
    for(int k=0;k<N_BOTTLES;k++)
    {
        io_board.set_press_motor(k, IOShield::STOP);
        io_board.set_bottle_piston(k, IOShield::STUCK);
    }

    std::chrono::milliseconds transition(300);
    std::this_thread::sleep_for(transition);

    // Turn on power (safe since relays are off)
    power_relay.initialize("4");
    power_relay.turn_on();

    cout << "Initializing LCDs" << endl;
    lcd_array.initialize(&io_board);

    cout << "Initializing sensors" << endl;
    temp_sensor.start();

    cout << "Initializing buttons" << endl;
    for(int k=0;k<N_BOTTLES;k++)
    {
        serving_buttons[k].initialize(&io_board,k,N_SERVING_SIZES, button_pressed, &event_notifier, true, N_BOTTLES);
    }

    cout << "Initializing press positions" << endl;
    for(int k=0;k<N_BOTTLES;k++)
    {
        wine_server.initialize_press(k);
        std::this_thread::sleep_for(transition);
    }

    cout << "Initializing pistons" << endl;
    for(int k=0;k<N_BOTTLES;k++)
    {
        io_board.set_bottle_piston(k, IOShield::UPWARD);
        std::this_thread::sleep_for(transition);
        io_board.set_bottle_piston(k, IOShield::STUCK);
    }

    cout << "Initializing NFC board." << endl;
	nfc_board.initialize(&event_notifier);

	cout << "Registering with Newine server..." << endl;

    while ((id = nw_api.register_with_server(uid)) == 0)
	{
        lcd_array.draw_lock.lock();
		for (int k=0;k<N_BOTTLES;k++)
		{
			lcd_array.displays[k].show_instructions("Connecting...", "UID: " + uid, "");
		}
        lcd_array.draw_lock.unlock();
	}

    cout << "Registration complete. ID: " << id << std::endl;

	update_idle_displays = true;

	return CONFIGURING;
}

DispenserStateID Dispenser::idle(void)
{
	if(update_idle_displays)
	{
		cout << "Waiting for NFC tag or configuration change" << endl;

        lcd_array.draw_lock.lock();
		for(int k=0;k<N_BOTTLES;k++)
		{
			lcd_array.displays[k].show_idle(superUserMode);
		}
        lcd_array.draw_lock.unlock();
	}

	chrono::seconds timeout(DISPENSER_PING_TIMEOUT);
	nw_api.ping_to_server(id);

	nfc_board.flag_down();
	reset_buttons_notifications();
	if(wait_for_wakeup_signal(timeout,[this]() {
		return nfc_board.card_present() || configuration.changed() || ((*button_pressed) && superUserMode);
	}))
	{
		update_idle_displays = true;
		if (nfc_board.card_present())
		{
			cout << "Card found" << endl;
			nfc_board.flag_down();
			return AUTHENTICATING;
		}

		if (configuration.changed())
		{
			cout << "Conf change" <<endl;
			configuration.flag_down();
			if(*configuration.shutdown_rqst)
				return SHUTTING_DOWN;
			else
				return CONFIGURING;
		}

		if (superUserMode) {
			*button_pressed=false;
			return AUTHENTICATING;
		}
	}

    nitro_sensor.update_value();
	update_idle_displays = false;
	return IDLE;
}

DispenserStateID Dispenser::configure(void)
{
	configuration.load(configuration_file_name);

	for(int k=0;k<N_BOTTLES;k++)
	{
		lcd_array.displays[k].update_wine(configuration.wine_names[k],configuration.wine_details[k],configuration.serving_options[k], configuration.remaining_volumes[k]);
	}

	return IDLE;
}

DispenserStateID Dispenser::authenticate(void)
{
	cout << "Authenticating tag" << endl;
	if (current_user != NULL)
		delete current_user;

	superUserMode=false;

	string user_id = nfc_board.get_user_id();

	cout << "User ID: " << user_id << endl;

	current_user = nw_api.users_get(user_id);

	if (current_user != NULL)
	{
		cout << "Valid user." << endl;

		if(current_user->name == "manager"){
			cout << "Manager Mode: free servings" << endl;
			superUserMode=true;
		}

        if (current_user->type == UserType::TECH_USER)
        {
            lcd_array.draw_lock.lock();
            for(int k=0;k<N_BOTTLES;k++)
            {
                lcd_array.displays[k].show_tech_panel();
            }
            lcd_array.draw_lock.unlock();
        }
        else if (current_user->type == UserType::TESTING_USER)
        {
            lcd_array.draw_lock.lock();
            for(int k=0;k<N_BOTTLES;k++)
            {
                lcd_array.displays[k].show_testing_panel();
            }
            lcd_array.draw_lock.unlock();
        }
		else if(current_user->can_detach || current_user->can_clean || current_user->can_set_temp)
		{
			//user is admin!
            lcd_array.draw_lock.lock();
			for(int k=0;k<N_BOTTLES;k++)
			{
				lcd_array.displays[k].show_authorized_admin(current_user->can_clean, current_user->can_detach);
				std::cout << "In bottle " << k << " remains " << std::dec << configuration.remaining_volumes[k] << " ml" << std::endl;
			}
            lcd_array.draw_lock.unlock();
		}
		else
		{
			//user is a client!
            lcd_array.draw_lock.lock();
			for(int k=0;k<N_BOTTLES;k++)
			{
				lcd_array.displays[k].show_authorized_client(current_user->credit, configuration.remaining_volumes[k], superUserMode);
				std::cout << "In bottle " << k << " remains " << std::dec << configuration.remaining_volumes[k] << " ml" << std::endl;
			}
            lcd_array.draw_lock.unlock();
		}
		*button_pressed=false;
		return AWAITING_SELECTION;
	}
	else
	{
		cout << "Unauthorized" << endl;

        lcd_array.draw_lock.lock();
		for(int k=0;k<N_BOTTLES;k++)
		{
			lcd_array.displays[k].show_unauthorized();
		}
        lcd_array.draw_lock.unlock();

		return IDLE;
	}
}

DispenserStateID Dispenser::await_selection(void)
{
    selected_bottle = 0;
    selected_serving = 0;
    cout << "Waiting for user selection" << endl;

    // Use a condition_variable to block, and unblock from buttons or with timeout.
    chrono::seconds timeout(USER_INPUT_TIMEOUT);

    reset_buttons_notifications();
    if(wait_for_wakeup_signal(timeout, [this](){
        bool p = (bool) * button_pressed;
        return p;
    }))
    {
        TouchEvent ev[N_BOTTLES];
        TouchEvent the_touch;
        bool valid_touch = true;
        bool already_touched = false;
        for(int k=0;k<N_BOTTLES;k++)
        {
            ev[k]= serving_buttons[k].get_event();
            if(ev[k].state != TOUCH_IDLE)
            {
                if(already_touched)
                {
                    valid_touch = false;
                    break;
                }

                selected_bottle = k;
                already_touched = true;
                the_touch = ev[k];
            }
        }
        *button_pressed = false;

        if(valid_touch && already_touched)
        {
            switch(the_touch.state)
            {
                case BUTTON_PRESSED:
                    selected_serving = the_touch.button;

                    if (current_user->type == UserType::TECH_USER)
                    {
                        switch ((TechPanelMenu) the_touch.button)
                        {
                            case TechPanelMenu::FLOWMETER_ADJUST:
                                std::cout << "Flowmeter adjust." << std::endl;
                                return SHOWING_FLOWMETER_ADJUST;

                            case TechPanelMenu::SERVING_ADJUST:
                                std::cout << "Serving adjust." << std::endl;
                                return SHOWING_SERVING_ADJUST;

                            case TechPanelMenu::PRESS_CONTROLS:
                                std::cout << "Press controls." << std::endl;
                                return SHOWING_PRESS_CONTROLS;
                        }
                    }
                    else if (current_user->type == UserType::TESTING_USER)
                    {
                        switch ((TestingPanelMenu) the_touch.button)
                        {
                            case TestingPanelMenu::TEST_PRESS:
                                std::cout << "Test press." << std::endl;
                                return PRESS_TESTING;

                            case TestingPanelMenu::RESET_TEST_DATA:
                                std::cout << "Reset test data." << std::endl;
                                cyc_testing.reset_recorded_data();

                                return IDLE;
                        }
                    }
                    else if(current_user->can_detach || current_user->can_clean || current_user->can_set_temp)
                    {
                        //user is admin!
                        if(selected_serving==0 && current_user->can_detach)
                        {
                            return DETACHING_AND_LOADING;
                        }
                        else if(selected_serving==1 && current_user->can_clean)
                        {
                            return CLEANING;
                        }
                        else if(selected_serving==2 && current_user->can_clean)
                        {
                            return SHOWING_INFO;
                        }
                        else
                            return AWAITING_SELECTION;
                    }
                    else
                    {
                        //user is a client!
                        cout << "Will serve size " << selected_serving << " from bottle " << selected_bottle << endl;
                        if(selected_serving>=N_SERVING_SIZES)
                        {
                            cout << "Invalid serving size" << endl;
                            return AWAITING_SELECTION;
                        }
                        return SERVING;
                    }
                    break;

                case SLIDE_RIGHT:
                    cout << "Slide right, no action here" << endl;
                    break;

                case SLIDE_LEFT:
                    cout << "Slide left, no action here" << endl;
                    break;

                case ALL_PRESSED:
                    cout << "All pressed, no action here" << endl;
                    break;

                default:
                    cout << "Invalid state: " << the_touch.state;
                    return AWAITING_SELECTION;
                    break;
            }
        }
        else
        {
            cout << "Two or more button arrays pressed. Still waiting for a valid action." << endl;
            return AWAITING_SELECTION;
        }
    }
    else
    {
        // Timeout occured.
        cout << "Timeout waiting for input" << endl;
    }

    return IDLE;
}

DispenserStateID Dispenser::serve(void)
{
    Serving * serv_opt = &(configuration.serving_options[selected_bottle][selected_serving]);
    NewineAPIServing serv(id,current_user->uid, selected_bottle, selected_serving, serv_opt -> price, serv_opt-> volume, current_user -> credit);

    NewineAPIServing * serv_out = nw_api.servings_post(&serv);
    if( (serv_out != NULL) && (serv_out->valid_serving) )
    {
        configuration.remaining_volumes[selected_bottle] -= serv_opt -> volume;

        std::cout << "serving !!!" << endl;

        lcd_array.draw_lock.lock();
        lcd_array.displays[selected_bottle].show_serving();
        lcd_array.displays[selected_bottle].update_volume(configuration.remaining_volumes[selected_bottle]);
        lcd_array.draw_lock.unlock();
        lcd_array.wait_for_update(); // Serving will block the SPI bus

        int vol = serv_opt -> volume;

        bool result = wine_server.serve_volume(vol, selected_bottle);

        if (result)
        {
            std::cout << "Serving was successful!" << std::endl;
        }
        else
        {
            std::cout << "Serving failed!" << std::endl;
        }

        return IDLE;
    }
    else
    {
        return AWAITING_SELECTION;
    }
}

DispenserStateID Dispenser::clean(void)
{
    std::cout << "Cleaning bottle - asking for confirmation" << selected_bottle << std::endl;
    std::chrono::milliseconds transition(3000);

    lcd_array.draw_lock.lock();
    show_inactive_stations();
    lcd_array.displays[selected_bottle].show_cleaning_confirmation();
    lcd_array.draw_lock.unlock();
    lcd_array.wait_for_update(); // Serving will block the SPI bus

    std::this_thread::sleep_for(transition);
   

    reset_buttons_notifications();
    wait_for_wakeup_signal(std::chrono::milliseconds(10000), [this](){
        return (bool) *button_pressed;
    });

    if (*button_pressed)
    {
        TouchEvent ev = serving_buttons[selected_bottle].get_event();
        if ((ev.state == BUTTON_PRESSED) && (ev.button == CLEAN_CONFIRM_OK))
        {

            lcd_array.draw_lock.lock();
            lcd_array.displays[selected_bottle].show_cleaning();
            lcd_array.draw_lock.unlock();
            lcd_array.wait_for_update(); // Serving will block the SPI bus

            wine_server.serve_volume(CLEANING_VOLUME, selected_bottle);
        }
    }

    return IDLE;
}

DispenserStateID Dispenser::show_info(void)
{
    int new_temp;
    bool temp_measured = temp_sensor.read(&new_temp);
    for(int k = 0; k < N_BOTTLES; k++)
    {
        if (temp_measured)
        {
            lcd_array.displays[k].update_temp(new_temp);
        }

        lcd_array.displays[k].update_nitro(nitro_sensor.get_value());
    }


    lcd_array.draw_lock.lock();
    for(int k=0;k<N_BOTTLES;k++)
    {
        lcd_array.displays[k].show_info(nw_api.wine_days(k, id), 0);
    }
    lcd_array.draw_lock.unlock();

    reset_buttons_notifications();
        wait_for_wakeup_signal(std::chrono::milliseconds(10000), [this](){ // A button press causes this to exit sooner
        return (bool) *button_pressed;
    });

     if (*button_pressed)
        {
            for(int k=0;k<N_BOTTLES;k++)
            {
                TouchEvent ev = serving_buttons[k].get_event();
                if ((ev.button == 2))
                {
                    nitro_sensor.recharge();
                    continue;
                }
            }
        }

    return IDLE;
}

DispenserStateID Dispenser::show_press_controls(void)
{
    lcd_array.draw_lock.lock();
    show_inactive_stations();
    lcd_array.displays[selected_bottle].show_press_controls();
    lcd_array.draw_lock.unlock();

    wine_server.initialize_press(selected_bottle);

    bool limit_switch;

    bool in_menu = true;

    while (in_menu)
    {
        reset_buttons_notifications();
        wait_for_wakeup_signal(std::chrono::milliseconds(1500), [this](){
            return (bool) *button_pressed;
        });
/*--------------------------------------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------------------------------------------*/     
        //Muestra estado del limit_switch 
        lcd_array.draw_lock.lock();
			
			limit_switch = wine_server.getLimitSwitchStatus();
			if(limit_switch)
			{
				lcd_array.displays[selected_bottle].show_message("Press closed");
				std::cout << "Fin de carrera (CNY70) cerrado" << endl;
			}
			else
			{
				lcd_array.displays[selected_bottle].show_message("Press opened");
				std::cout << "Fin de carrera (CNY70) abierto" << endl;
			}

        lcd_array.draw_lock.unlock();
	
/*--------------------------------------------------------------------------------------------------------------*/       
/*--------------------------------------------------------------------------------------------------------------*/


        if (*button_pressed)
        {
            TouchEvent ev = serving_buttons[selected_bottle].get_event();
            if (ev.state == BUTTON_PRESSED)
            {
                switch ((PressMenu) ev.button)
                {
                    case PressMenu::OPEN:
                        io_board.set_press_motor(selected_bottle, IOShield::BACKWARD);
                        std::this_thread::sleep_for(std::chrono::milliseconds(300));
                        io_board.set_press_motor(selected_bottle, IOShield::STOP);
                        break;

                    case PressMenu::CLOSE:
                        io_board.set_press_motor(selected_bottle, IOShield::FORWARD);
                        std::this_thread::sleep_for(std::chrono::milliseconds(300));
                        io_board.set_press_motor(selected_bottle, IOShield::STOP);
                        break;

                    case PressMenu::EXIT:
                        in_menu = false;
                        break;
                }
            }
        }
    }

    return IDLE;
}

DispenserStateID Dispenser::show_flowmeter_adjust(void)
{
    lcd_array.draw_lock.lock();
    show_inactive_stations();
    lcd_array.draw_lock.unlock();

    bool in_menu = true;

    while (in_menu)
    {
        lcd_array.draw_lock.lock();
        lcd_array.displays[selected_bottle].show_flowmeter_adjust();
        lcd_array.draw_lock.unlock();

        reset_buttons_notifications();
        wait_for_wakeup_signal(std::chrono::milliseconds(20000), [this](){
            return (bool) *button_pressed;
        });

        TouchEvent event;
        if (!*button_pressed)
        {
            in_menu = false;
            continue;
        }

        event = serving_buttons[selected_bottle].get_event();
        if ((event.state != BUTTON_PRESSED) || ((FlowAdjust) event.button == FlowAdjust::EXIT))
        {
            in_menu = false;
            continue;
        }
        else if((FlowAdjust) event.button == FlowAdjust::RESET_CALIB)
        {
            wine_server.config.reset_whole_pulse_volume(selected_bottle); 
            in_menu = false;
            continue;
        }

        int serving_time = 7000;
        float measured;
        bool successs = wine_server.serve_time(serving_time, selected_bottle, &measured);
        int actual_measure = measured;
        lcd_array.draw_lock.lock();
        lcd_array.displays[selected_bottle].show_flowmeter_adjust_controls(measured, actual_measure, successs);
        lcd_array.draw_lock.unlock();

        reset_buttons_notifications();
        wait_for_wakeup_signal(std::chrono::milliseconds(20000), [this](){
            return (bool) *button_pressed;
        });

        if (!*button_pressed)
        {
            in_menu = false;
            continue;
        }

        event = serving_buttons[selected_bottle].get_event();
        if ((event.state != BUTTON_PRESSED) || (event.button == 1))
        {
            in_menu = false;
            continue;
        }

        while(!(event.button == 1))
        {
            if (event.button == 2)
            {
                actual_measure++;
            }
            else if (event.button == 0)
            {
                actual_measure--;
            }

            

            lcd_array.draw_lock.lock();
            lcd_array.displays[selected_bottle].show_flowmeter_adjust_controls(measured,actual_measure);
            lcd_array.draw_lock.unlock();

            reset_buttons_notifications();
            wait_for_wakeup_signal(std::chrono::milliseconds(20000), [this](){
                return (bool) *button_pressed;
            });


            if (!*button_pressed)
            {
                in_menu = false;
                continue;
            }

            event = serving_buttons[selected_bottle].get_event();
            if ((event.state != BUTTON_PRESSED))
            {
                in_menu = false;
                continue;
            }
            if(event.button == 1)
            {
                wine_server.config.set_whole_pulse_volume(selected_bottle, measured, actual_measure); 
                in_menu = false;
                continue;
            }

        }
    }

    return IDLE;
}

DispenserStateID Dispenser::show_serving_adjust(void)
{
    lcd_array.draw_lock.lock();
    show_inactive_stations();
    lcd_array.draw_lock.unlock();

    bool in_menu = true;

    while (in_menu)
    {
        lcd_array.draw_lock.lock();
        lcd_array.displays[selected_bottle].show_serving_adjust();
        lcd_array.draw_lock.unlock();

        reset_buttons_notifications();
        wait_for_wakeup_signal(std::chrono::milliseconds(20000), [this](){
            return (bool) *button_pressed;
        });

        TouchEvent event;
        if (!*button_pressed)
        {
            in_menu = false;
            continue;
        }

        event = serving_buttons[selected_bottle].get_event();
        if ((event.state != BUTTON_PRESSED) || ((ServeAdjust) event.button == ServeAdjust::EXIT))
        {
            in_menu = false;
            continue;
        }
        else if((ServeAdjust) event.button == ServeAdjust::RESET_OFFSET)
        {
            wine_server.config.reset_control_volume_offset(selected_bottle); 
            in_menu = false;
            continue;
        }

        int serving_volume = 50;
        bool success = wine_server.serve_volume(serving_volume, selected_bottle);

        lcd_array.draw_lock.lock();
        lcd_array.displays[selected_bottle].show_serving_adjust_query(serving_volume, success);
        lcd_array.draw_lock.unlock();

        reset_buttons_notifications();
        wait_for_wakeup_signal(std::chrono::milliseconds(20000), [this](){
            return (bool) *button_pressed;
        });

        if (!*button_pressed)
        {
            in_menu = false;
            continue;
        }

        event = serving_buttons[selected_bottle].get_event();
        if ((event.state != BUTTON_PRESSED) || ((ServeAdjustQuery) event.button == ServeAdjustQuery::EXIT))
        {
            in_menu = false;
            continue;
        }

        ServeAdjustQuery adjust = ((ServeAdjustQuery) event.button);
        if (adjust == ServeAdjustQuery::SERVED_MORE)
        {
            wine_server.config.increase_control_volume_offset(selected_bottle);
        }
        else if (adjust == ServeAdjustQuery::SERVED_LESS)
        {
            wine_server.config.decrease_control_volume_offset(selected_bottle);
        }
    }

    return IDLE;
}

DispenserStateID Dispenser::detach_and_load(void)
{
 //   cout << "Will detach bottle " << selected_bottle << endl;
    std::chrono::milliseconds transition(2800);
    

    lcd_array.draw_lock.lock();
    show_inactive_stations();
    lcd_array.displays[selected_bottle].show_changing_bottle();
    lcd_array.draw_lock.unlock();

    std::this_thread::sleep_for(transition);
    *button_pressed = false;

	TouchEvent ev;
	bool valid_input = false;


	wait_for_wakeup_signal([this](){
	bool p = *button_pressed;
	return p;
	});

	ev = serving_buttons[selected_bottle].get_event();
	*button_pressed = false;
	
    if(ev.button == 2)
		return IDLE;
    if(ev.button == 0)
    {

        lcd_array.draw_lock.lock();
    	lcd_array.displays[selected_bottle].show_replaced();
        lcd_array.draw_lock.unlock();

        
        std::this_thread::sleep_for(transition);

        *button_pressed = false;
        valid_input = false;

        // Puchitou or cancel
    	while(!valid_input)
    	{
    		wait_for_wakeup_signal([this](){
    		bool p = *button_pressed;
    		return p;
    		});

    		ev = serving_buttons[selected_bottle].get_event();
    		if(ev.state == BUTTON_PRESSED && ev.button!=1)
    			valid_input = true;
    		else
    			valid_input = false;

    		*button_pressed = false;
    	}
    	*button_pressed = false;

    	if(ev.button == 2)
    	{
    		// No puchitout
            nw_api.wine_replace_post(selected_bottle, id);
            return IDLE;
    	}


        lcd_array.draw_lock.lock();
        lcd_array.displays[selected_bottle].show_serving();
        lcd_array.draw_lock.unlock();

        int vol = PUCHITOU_VOLUME;

        nw_api.wine_replace_post(selected_bottle, id); 
        nw_api.wine_taste_post(selected_bottle, id);
        wine_server.serve_volume(vol,selected_bottle); 
        return IDLE;
    }
    if(ev.button == 1)
    {
        return SELECTING_WINE;
    }
	return IDLE;
}

DispenserStateID Dispenser::test_press(void)
{
    cyc_testing.test_press(5, button_pressed);

    bool exit_menu = false;
    while (!exit_menu)
    {
        reset_buttons_notifications();
        wait_for_wakeup_signal([this](){
            return (bool) *button_pressed;
        });

        if (*button_pressed)
        {
            exit_menu = true;
        }
    }

    return IDLE;
}

void Dispenser::show_inactive_stations(void)
{
    for (int i = 0; i < N_BOTTLES; ++i)
    {
        if (i != selected_bottle)
        {
            lcd_array.displays[i].show_inactive_station();
        }
    }
}

DispenserStateID Dispenser::shut_down(void)
{
    std::cout << "SHUTTING DOWN" << std::endl;

    if (current_user != NULL)
        delete current_user;

    delete button_pressed;

    //displays[N_BOTTLES] -> doesn't need stop function
    for(int k=0;k<N_BOTTLES;k++)
    {
        serving_buttons[k].stop();
    }

    io_board.stop();

    nfc_board.stop();
    std::cout << "nfc_board stopped correctly" << std::endl;

    power_relay.stop();
    std::cout << "power_relay stopped correctly" << std::endl;

    *shutdown = true;
}

DispenserStateID Dispenser::select_wine(void)
{
    std::cout << "Displaying wine list." << std::endl;
    std::chrono::milliseconds transition(3000);
    
    int  wine_id[WINE_LIST_MAX_SIZE];
    std::string wine_list_names[WINE_LIST_MAX_SIZE];
    std::string wine_list_details[WINE_LIST_MAX_SIZE];

    int list_size;
    nw_api.wine_list_get(&list_size, wine_id, wine_list_names, wine_list_details);   //Gets wine list from server and saves it in "wine_list_names[]" and "wine_list_details[]"
        
    int wine_list_start = 0;                                                         //Wine index in the list, indicates which element must be displayed. (there are N_LIST_ELEMENTS)

    lcd_array.draw_lock.lock();
    show_inactive_stations();
    lcd_array.displays[selected_bottle].show_wine_list(wine_list_names[wine_list_start], wine_list_details[wine_list_start]);
    lcd_array.draw_lock.unlock();

    std::this_thread::sleep_for(transition);
    *button_pressed = false;

    TouchEvent ev;

    while(ev.button != 1)
    {
        reset_buttons_notifications();
        wait_for_wakeup_signal(std::chrono::milliseconds(10000), [this](){
            return (bool) *button_pressed;
        });
        if(!*button_pressed)
        return IDLE;  

        ev = serving_buttons[selected_bottle].get_event();
        if(ev.state == BUTTON_PRESSED)                                                  
        {
            if(ev.button == 0) //Boton DOWN 
            {
                if(++wine_list_start == list_size)                                
                    wine_list_start -= list_size;                                 //Starts again when list's element selector overflows
                lcd_array.draw_lock.lock();
                show_inactive_stations();
                lcd_array.displays[selected_bottle].show_wine_list(wine_list_names[wine_list_start], wine_list_details[wine_list_start]);    
                lcd_array.draw_lock.unlock();
            }
            else if(ev.button == 2) //Boton UP
            {
                if(--wine_list_start < 0)
                    wine_list_start += list_size;
                lcd_array.draw_lock.lock();
                show_inactive_stations();
                lcd_array.displays[selected_bottle].show_wine_list(wine_list_names[wine_list_start], wine_list_details[wine_list_start]);
                lcd_array.draw_lock.unlock();
            }
            else if(ev.button == 1) //boton OK
            {
                cout << "Selected wine #" << (wine_list_start+1) << endl;
                

                lcd_array.draw_lock.lock();
                lcd_array.displays[selected_bottle].show_changed();
                lcd_array.draw_lock.unlock();

                *button_pressed = false;
                bool valid_input = false;

                // Puchitou or cancel
                while(!valid_input)
                {
                    wait_for_wakeup_signal([this](){
                    bool p = *button_pressed;
                    return p;
                    });

                    ev = serving_buttons[selected_bottle].get_event();
                    if(ev.state == BUTTON_PRESSED && ev.button!=1)
                        valid_input = true;
                    else
                        valid_input = false;

                    *button_pressed = false;
                }
                *button_pressed = false;

                if(ev.button == 2)
                {
                    // No puchitout
                    nw_api.wine_list_post(wine_id[wine_list_start],selected_bottle, id);
                    return IDLE;
                }

                lcd_array.draw_lock.lock();
                lcd_array.displays[selected_bottle].show_serving();
                lcd_array.draw_lock.unlock();

                int vol = PUCHITOU_VOLUME;

                wine_server.serve_volume(vol, selected_bottle);

		std::cout << "Posting to server" << std::endl;
                nw_api.wine_list_post(wine_id[wine_list_start],selected_bottle, id); 
                nw_api.wine_taste_post(selected_bottle, id);
                std::cout << "IDLE" << std::endl;
		return IDLE;
            }
		
        }

         
    }
}

void Dispenser::wait_for_wakeup_signal(function<bool (void)> test)
{
    unique_lock<mutex> l(lock);

    event_notifier.wait(l,test);
}

bool Dispenser::wait_for_wakeup_signal(chrono::milliseconds timeout, function<bool (void)> test)
{
    unique_lock<mutex> l(lock);

    return event_notifier.wait_for(l,timeout,test);

}

std::string Dispenser::get_uid(void)
{
    std::ifstream eeprom("/sys/bus/i2c/devices/0-0050/eeprom", std::ifstream::in);

    char ser[29];

    eeprom.get(ser,29);

    std::string str(&ser[16]);

    return str;
}

void Dispenser::reset_buttons_notifications(void)
{
    *button_pressed=false;
    for(int k=0;k<N_BOTTLES;k++)
    {
        serving_buttons[k].clean_event();
    }
}

