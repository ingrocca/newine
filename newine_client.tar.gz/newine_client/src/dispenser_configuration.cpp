#include "dispenser_configuration.hpp"
#include <iostream>
#include <fstream>
#include <jansson.h>
using namespace std;
// TODO
DispenserConfiguration::DispenserConfiguration(unsigned int n_tmps, unsigned int n_bttles, unsigned int n_srving_sizes, std::condition_variable * ev_not)
{
	n_temps = n_tmps;
	n_serving_sizes = n_srving_sizes;
	n_bottles = n_bttles;
	ev_notifier = ev_not;

	temperature = new double[n_tmps];
	serving_options = new Serving*[n_bottles];
	for(int i=0; i< n_bottles; i++)
		serving_options[i] = new Serving[n_serving_sizes];

	remaining_volumes = new int[n_bottles];
	wine_names = new std::string[n_bottles];
	wine_details = new std::string[n_bottles];

	shutdown = new std::atomic<bool>(false);
	shutdown_rqst =  new std::atomic<bool>(false);
	change = new std::atomic<bool>(false);
	listener = new std::thread([this](){
		listener_task();
	});

	// Start change listener
}

// TODO
DispenserConfiguration::~DispenserConfiguration(void)
{
    // Stop and join change listener

    *shutdown = true;
    listener -> join();

    delete shutdown;
    delete listener;
    delete shutdown_rqst;
    delete change;

    for(int i=0; i< n_serving_sizes; i++)
        delete serving_options[i];

	delete temperature;
	delete product_ids;
	delete serving_options;
	delete remaining_volumes;
	delete wine_names;
	delete wine_details;
}

// TODO
void DispenserConfiguration::load(const char * fname)
{
	ifstream fin(fname,std::ios_base::in);
	string v;
	getline(fin, v);
	fin.close();

	json_error_t error;

	json_t	*root = json_loads(v.c_str(), 0, &error);
	if(!root)
	{
	    cout << "Configuration::load error: on line " << error.line << ": " << error.text << endl;
	    return;
	}

	json_t * serving_opt,  * wine_nms, *wine_dtls, *remaining_vlms,* temps;

//	cout << "unpacking "<<endl;
	json_unpack(root,"{s:o, s:o, s:o, s:o, s:o}", "serving_options",&serving_opt, "wine_names", &wine_nms, "wine_details", &wine_dtls, "temperatures", &temps, "remaining_volumes", &remaining_vlms);

	size_t idx;
	json_t *val;

//	cout << " serving opts "<<endl;
	json_array_foreach(serving_opt, idx,val){
		json_t * low, * med, * high;

//		cout << "srv.opt. "<< idx << endl;

		json_unpack(val,"{s:o,s:o,s:o}","low",&low,"med",&med,"high",&high);
		serving_options[idx][0].price = json_real_value(json_object_get(low,"price"));
		serving_options[idx][0].volume = json_integer_value(json_object_get(low,"volume"));

		serving_options[idx][1].price = json_real_value(json_object_get(med,"price"));
		serving_options[idx][1].volume = json_integer_value(json_object_get(med,"volume"));

		serving_options[idx][2].price = json_real_value(json_object_get(high,"price"));
		serving_options[idx][2].volume = json_integer_value(json_object_get(high,"volume"));
	}
	size_t idx2;
	json_t *val2;

//	cout << "w names"<<endl;
	json_array_foreach(wine_nms,idx2,val2){
		wine_names[idx2] = json_string_value(val2);
	}

	size_t idx3;
	json_t *val3;

//	cout << "w details"<<endl;
	json_array_foreach(wine_dtls,idx3,val3){
		wine_details[idx3] = json_string_value(val3);
	}

	size_t idx4;
	json_t *val4;
//	cout << "temps "<<endl;
	json_array_foreach(temps,idx4,val4){
		temperature[idx4] = json_real_value(val4);

		if(!temperature[idx4])
		{
			temperature[idx4] = json_integer_value(val4);
		}
//		cout << "Temp from file: "<< temperature[idx4] << endl;
	}

	size_t idx5;
	json_t *val5;
//	cout << "remaining volumes" << endl;
	json_array_foreach(remaining_vlms,idx5,val5){
		remaining_volumes[idx5] = json_integer_value(val5);
	}

//	cout << " decref "<<endl;
	json_decref(root);
//	cout << " done "<<endl;
}

// TODO
void DispenserConfiguration::save(const char * fname)
{

}

// TODO
bool DispenserConfiguration::changed(void)
{
    bool c = (bool)*change;
    return c;
}

void DispenserConfiguration::flag_down(void)
{
    *change = false;
}

void DispenserConfiguration::listener_task(void)
{
    ifstream f("/home/newine/newine_client/conf_server/newine_conf_fifo",ios_base::in);
    while(!*shutdown)
    {
        string val;

        getline(f,val);
        *change = true;

        if(val[0]!= '{')
        {
            if( val.compare("SHUTDOWN") == 0 )
            {
                std::cout << "SHUTDOWN received" << endl;
                *shutdown_rqst = true;
                ev_notifier->notify_one();
            }
        }
        else
        {
            // Update config file
            ofstream f_out(configuration_file_name);
            f_out << val << endl;
            f_out.close();

            ev_notifier->notify_one();
        }

        std::chrono::milliseconds sleep_time( 1000 );
        std::this_thread::sleep_for(sleep_time);
    }
}