#include "dispenser.hpp"

using namespace std;
int main(void)
{
    Dispenser disp;

    cout<< "UID: " << disp.get_uid() << endl;
}