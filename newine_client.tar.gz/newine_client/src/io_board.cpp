#include "io_board.hpp"

#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/ioctl.h>

IOBoard::IOBoard(int bus, int chan, int bnk_size,int spd)
{
    bank_size = bnk_size;
    spi_bus = bus;
    spi_chan = chan;
    inputs = new unsigned char[bank_size];
    outputs = new unsigned char[bank_size];
    length = bank_size;
    speed = spd;
}

void IOBoard::initialize(void)
{
    spi.open(spi_bus,spi_chan);
    spi.setSpeed(speed);
    spi.setMode(0);
}

void IOBoard::stop(void)
{
    spi.close();
    delete inputs;
    delete outputs;
}

unsigned char IOBoard::get(int position)
{
    unsigned char d;
    lock.lock();
    d = non_blocking_get(position);
    lock.unlock();
    return d;
}

unsigned char IOBoard::non_blocking_get(int position)
{
    perform_transfer();
    return async_get(position);
}

unsigned char IOBoard::async_get(int position)
{
    return inputs[bank_size-1-position];
}

void IOBoard::set(unsigned char value, unsigned char mask, int position)
{
    lock.lock();
    outputs[position] = (outputs[position] & ~mask) | (value & mask);
    perform_transfer();
    lock.unlock();
}

void IOBoard::set(unsigned char *value, unsigned char *mask, int position, int n_bytes)
{
    lock.lock();
    for(int i=0; i<n_bytes; i++)
    {
        outputs[position+i] = (outputs[position+i] & ~mask[i]) | (value[i] & mask[i]);
    }
    perform_transfer();
    lock.unlock();
}

void IOBoard::non_blocking_set(unsigned char *value, unsigned char *mask, int position, int n_bytes)
{
    for(int i=0; i<n_bytes; i++)
    {
        outputs[position+i] = (outputs[position+i] & ~mask[i]) | (value[i] & mask[i]);
    }
    perform_transfer();
}

void IOBoard::perform_transfer(void)
{
    //std::cout << "XFER " << bank_size;
    spi.xfer1(outputs,inputs,(int)bank_size);
}

void IOBoard::lock_updates(void)
{
    lock.lock();
}

void IOBoard::unlock_updates(void)
{
    lock.unlock();
}
