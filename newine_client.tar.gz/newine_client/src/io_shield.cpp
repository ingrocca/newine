#include "io_shield.hpp"

#define MOTOR_CLEAR_MASK (0xCFFF)
#define STOP_MOTOR_BITS (1 << 13 | 1 << 12)
#define BACKWARD_MOTOR_BITS (1 << 13 | 0 << 12)
#define FORWARD_MOTOR_BITS (0 << 13 | 1 << 12)

#define PISTON_CLEAR_MASK (0x3FFF)
#define STOP_PISTON_BITS (1 << 15 | 1 << 14)
#define UPWARD_PISTON_BITS (1 << 15 | 0 << 14)
#define DOWNWARD_PISTON_BITS (0 << 15 | 1 << 14)

IOShield::IOShield(int bus, int chan, int n_shields, int spd):
    IOBoard(bus, chan, n_shields*2, spd)
{
    out = new std::bitset<16>[n_shields];
    total_shields = n_shields;
    for(int i=0; i<n_shields;i++)
    {
        clear_display_cs(i,0);
        clear_display_cs(i,1);
    }
}

void IOShield::initialize()
{
    IOBoard::initialize();
}

void IOShield::stop(void)
{
    delete out;
    IOBoard::stop();
}

// if i=5 all leds are set
void IOShield::set_led(unsigned char shield, unsigned char i)
{
    out[shield] |= (1<<led[i]);
    non_blocking_flush();
}

// if i=5 all leds are clear
void IOShield::clear_led(unsigned char shield, unsigned char i)
{
    out[shield] &= ~(1<<led[i]);
    non_blocking_flush();
}

void IOShield::set_press_motor(unsigned char shield, MotorDirection direction)
{
    out[shield] &= MOTOR_CLEAR_MASK;
    switch (direction)
    {
        case STOP:
            out[shield] |= STOP_MOTOR_BITS;
            break;
        case FORWARD:
            out[shield] |= FORWARD_MOTOR_BITS;
            break;
        case BACKWARD:
            out[shield] |= BACKWARD_MOTOR_BITS;
            break;
        default:
            out[shield] |= STOP_MOTOR_BITS;
            break;
    }

    non_blocking_flush();
}

void IOShield::set_bottle_piston(unsigned char shield, PistonDirection direction)
{
    out[shield] &= PISTON_CLEAR_MASK;
    switch (direction)
    {
        case STUCK:
            out[shield] |= STOP_PISTON_BITS;
            break;
        case UPWARD:
            out[shield] |= UPWARD_PISTON_BITS;
            break;
        case DOWNWARD:
            out[shield] |= DOWNWARD_PISTON_BITS;
            break;
        default:
            out[shield] |= STOP_PISTON_BITS;
            break;
    }

    non_blocking_flush();
}

void IOShield::set_display_data(unsigned char shield, char data)
{
    out[shield][DB0] = data&(1<<0);
    out[shield][DB1] = data&(1<<1);
    out[shield][DB2] = data&(1<<2);
    out[shield][DB3] = data&(1<<3);
    out[shield][DB4] = data&(1<<4);
    out[shield][DB5] = data&(1<<5);
    out[shield][DB6] = data&(1<<6);
    out[shield][DB7] = data&(1<<7);
}

void IOShield::set_display_cs(unsigned char shield, unsigned char i)
{
    out[shield] |= (1<<display_cs[i]);
}

void IOShield::clear_display_cs(unsigned char shield, unsigned char i)
{
    out[shield] &= ~(1<<display_cs[i]);

}

void IOShield::set_display_di(unsigned char shield)
{
    out[shield] |= (1<<DI);
}

void IOShield::clear_display_di(unsigned char shield)
{
    out[shield] &= ~(1<<DI);
}

void IOShield::flush(void)
{
    for(int i=0; i<total_shields ; i++)
    {
        unsigned long ulong_out = out[i].to_ulong();
        unsigned char char_out[2];
        char_out[1] = static_cast<unsigned char>( ulong_out );
        char_out[0] = static_cast<unsigned char>( ulong_out >> 8 );
        unsigned char mask[2] = {0xff,0xff};
        set(char_out, mask, i*2, 2);
    }
}

void IOShield::non_blocking_flush(void)
{
    unsigned char char_out[total_shields*2];
    unsigned char mask[total_shields*2];
    for(int i=0; i<total_shields ; i++)
    {
        unsigned long ulong_out = out[i].to_ulong();

        char_out[2*i + 1] = static_cast<unsigned char>( ulong_out );
        char_out[2 * i] = static_cast<unsigned char>( ulong_out >> 8 );
        mask[2*i] = 0xFF;
        mask[2*i+1] = 0xFF;
    }
    non_blocking_set(char_out, mask, 0, total_shields*2);
}
