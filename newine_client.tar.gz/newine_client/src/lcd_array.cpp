#include "lcd_array.hpp"
#include <iostream>

void LCDArray::initialize(IOShield *board)
{
    this->board = board;

    for(int k=0;k<N_BOTTLES;k++)
    {
        displays[k].initialize(board, k, false); // The LCD's are automatically turned periodically in the update task
        displays[k].show_init();
    }

    on_counter = 0;

    updated = new std::atomic<bool>(false);
    shutdown = new std::atomic<bool>(false);

    updater = new std::thread([this](){
        update_task();
    });
}

LCDArray::~LCDArray(void)
{
    *shutdown = true;
    updater->join();
}

void LCDArray::update_task(void)
{
    while(!(*shutdown))
    {
        draw_lock.lock();
        board->lock_updates();

        if (on_counter == 0)
        {
            on_counter = 10; // Roughly every 10 seconds
            mass_turn_on(); // This dims the screens a bit, but is necessary in case a 'turn off' command is issued due to EMI
        }
        else
        {
            --on_counter;
        }

        mass_set_start_line(0); // This instruction might be incorrectly issued due to EMI - this fixes vertical screen tearing
        for(int page = 0; page < WG12864A_HEIGHT/8; page++)
        {
            mass_set_page(page);
            mass_set_y_address(0);   // After writing The Y address is increased by 1 automatically.

            mass_set_display_cs(1);
            mass_clear_display_cs(0);
            for(int y = 0; y < WG12864A_WIDTH/2; y++)
            {
                mass_write_data(y, page);
            }

            mass_clear_display_cs(1);
            mass_set_display_cs(0);
            for(int y=WG12864A_WIDTH/2; y<WG12864A_WIDTH; y++)
            {
                mass_write_data(y, page);
            }
        }

        mass_clear_display_cs(0);
        mass_clear_display_cs(1);

        board->non_blocking_flush();

        board->unlock_updates();
        draw_lock.unlock();

        *updated = true;
    }
}

void LCDArray::wait_for_update(void)
{
    *updated = false;

    while (!(*updated))
    {
        std::chrono::milliseconds wait_time(10);
        std::this_thread::sleep_for(wait_time);
    }
}

void LCDArray::mass_execute_instruction(char instr_data)
{
    mass_set_display_cs(0);
    mass_set_display_cs(1);

    for (int i = 0; i < N_BOTTLES; ++i)
    {
        board->clear_display_di(i);
        board->set_display_data(i, instr_data);
    }

    board->non_blocking_flush();

    mass_clear_display_cs(0);
    mass_clear_display_cs(1);
}

void LCDArray::mass_turn_on(void)
{
    mass_execute_instruction(WG12864A_ON);

    std::chrono::milliseconds sl(100);
    std::this_thread::sleep_for(sl);
}

void LCDArray::mass_set_start_line(char address)
{
    mass_execute_instruction(WG12864A_START_LINE | (address & WG12864A_START_LINE_MASK));
}

void LCDArray::mass_set_page(char x_address)
{
    mass_execute_instruction(WG12864A_SET_PAGE | (x_address & WG12864A_SET_PAGE_MASK));
}

void LCDArray::mass_set_y_address(char y_address)
{
    mass_execute_instruction(WG12864A_SET_Y | (y_address & WG12864A_SET_Y_MASK));
}

void LCDArray::mass_set_display_cs(unsigned char i)
{
    for (int k = 0; k < N_BOTTLES; ++k)
    {
        board->set_display_cs(k, i);
    }
}

void LCDArray::mass_clear_display_cs(unsigned char i)
{
    for (int k = 0; k < N_BOTTLES; ++k)
    {
        board->clear_display_cs(k, i);
    }
}

void LCDArray::mass_write_data(int y, int page)
{
    for (int i = 0; i < N_BOTTLES; ++i)
    {
        board->set_display_di(i);
        board->set_display_data(i, displays[i].graphic.fb[y][page]);
    }

    board->non_blocking_flush();
}