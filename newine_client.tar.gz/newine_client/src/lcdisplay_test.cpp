#include "io_shield.hpp"
#include "lcdisplay.hpp"
#include <chrono>
#include <thread>
#include <iostream>

using namespace std;
int main (void)
{
    IOShield board(1, 0, 1);
    board.initialize();

    LCDisplay display;
    display.initialize(&board, 0);

    std::chrono::seconds sleep_time(2);

    for(int i=0; i<3; i++)
    {
        cout << "Showing authorized screen (Triangle)" << endl;
        //board.set_led(0,1);
        //board.clear_led(0,0);

        display.show_unauthorized();
        std::this_thread::sleep_for(sleep_time);
        cout << "Showing unauthorized screen (Circle)" << endl;
        //board.set_led(0,0);
        //board.clear_led(0,1);
        display.show_authorized();
        std::this_thread::sleep_for(sleep_time);
    }

    return 0;
}
