// main.cpp

#include "dispenser.hpp"
#include <stdlib.h>

void system_shut_down(void);

int main (void)
{
    Dispenser * dispenser = new Dispenser();

    // TODO call dispenser.run() in a new thread
    dispenser -> run();

    atexit(system_shut_down);

    return 0;
}

void system_shut_down(void)
{
    system("sudo shutdown -P -h now");
}