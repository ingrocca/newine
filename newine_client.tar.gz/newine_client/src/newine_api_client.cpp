
#include "newine_api_client.hpp"

using namespace std;
// TODO
int NewineAPIClient::register_with_server(std::string uid)
{
    json_t * j = json_pack("{s:s}","uid",uid.c_str());
    char * s = json_dumps(j,0);
    std::string ss = (std::string) s;
    free(s);

    std::string url = api_server_url + api_register_route + ".json";

    RestClient::response r = RestClient::post(url,"application/json",ss);

    if(r.code >= 200 && r.code < 300)
    {
        json_error_t error;
        json_t * root = json_loads(r.body.c_str(), 0, &error);
        if(!root)
        {
            cout << "error: on line " << error.line << ": " << error.text << endl;
            return 0;
        }

        int id;
        json_unpack(root,"{s:i}","id",&id);
        char *s = json_dumps(root, 0);
        std::cout << std::string(s) << std::endl;


        return id;
    }
    else
    {
        cout << "Received error code while registering: " << r.code << endl;
        return 0;
    }
}

bool NewineAPIClient::ping_to_server(int id)
{
    json_t * j = json_pack("{s:i}","id",id);
    char * s = json_dumps(j,0);
    std::string ss = (std::string) s;
    free(s);

    std::string url = api_server_url + api_ping_route + ".json";

    std::cout << ss <<endl;

    RestClient::response r = RestClient::post(url,"application/json",ss);

    if(r.code >= 200 && r.code < 300)
    {
        return true;
    }

    return false;
}
void NewineAPIClient::wine_list_get(int * list_size, int wine_id[], string wine_list_names[], string wine_list_details[])        //Lista de vinos al cambiar una botella
{
    // COMENTO PARA PROBAR EL RESTO DEL CODIGO SIN DEPENDER DEL SERVIDOR
    std::cout << "Displaying wine list." << std::endl;
    std::string url = api_server_url + api_wine_list_route + ".json"; //url guardada en el .hpp 
    std::cout << url << std::endl;

    RestClient::response r = RestClient::get(url);                    //get wine list
    std::cout << r.body.c_str() << std::endl;

    json_t * root;
    json_error_t error;
    //std::string resp = r.body.c_str();
    

    //root = json_loads(resp.substr(1, resp.size() - 2).c_str(), 0, &error);
    root = json_loads(r.body.c_str(), 0, &error);
    //std::cout << resp.substr(1, resp.size() - 2).c_str() << std::endl;
    if(!root)
    {
        cerr << "error: on line " << error.line << ": " << error.text << endl;
    }

    size_t idr = json_array_size(root);
    
    json_t * valr;
    json_t * object;
    json_t * value_obj;
    json_t * variety_name;

    for(size_t i=0; i < idr ; i++)
    {
        object = json_array_get(root,i);
        if(object != NULL)
        { 
            value_obj = json_object_get(object,"id");

            if(value_obj != NULL)
            { 
                wine_id[i] = json_number_value(value_obj);
                std::cout << wine_id[i] << std::endl;
            }
            else
            {
                std::cout << "id null" << std::endl;
            }

            value_obj = json_object_get(object,"name");

            if(value_obj != NULL)
            { 
                wine_list_names[i] = json_string_value(value_obj);
                std::cout << wine_list_names[i] << std::endl;
            }
            else
            {
                std::cout << "name null" << std::endl;
            }

            value_obj = json_object_get(object,"vintage");

            if(value_obj != NULL)
            { 
                wine_list_details[i] = std::to_string((int)json_number_value(value_obj));
            }
            else
            {
                std::cout << "vintage null" << std::endl;
            }

            value_obj = json_object_get(object,"variety");
            variety_name = json_object_get(value_obj,"name");
            string variety_cast =json_string_value(variety_name);
            if(value_obj != NULL)
            { 
                wine_list_details[i] = variety_cast + " " + wine_list_details[i];
                std::cout << wine_list_details[i] << std::endl;
            }
            else
            {
                std::cout << "variety null" << std::endl;
            }


        }
        else
        {
            std::cout << "array null" << std::endl;
        }

        *list_size = idr;
        
    }

    json_decref(root);
    /*
    //HARDCODEO LISTA DE VINOS PARA TESTEAR SIN SERVIDOR:
    wine_id[0] = 0;
    wine_id[1] = 1;
    wine_id[2] = 2;
    wine_id[3] = 3;
    wine_list_names[0] = "Vacio";
    wine_list_names[1] = "Vino 1";
    wine_list_names[2] = "Vino 2";
    wine_list_names[3] = "Vino 3";
    wine_list_details[0] = "";
    wine_list_details[1] = "Cosecha 1";
    wine_list_details[2] = "Cosecha 2";
    wine_list_details[3] = "Cosecha 3";
    *list_size = 4; 
*/
}
int NewineAPIClient::wine_taste_post(int bottle_index, int disp_id)
{

    std::string url = "192.168.0.1:3000/bottle_holder/taste";
    cout << url << endl;
        
    json_t * j =  json_pack("{s:i, s:i}",
                            "dispenser_id", disp_id,
                            "dispenser_index", bottle_index);


    //std::cout<<" root ";
    char * s = json_dumps(j,0);
    //std::cout << " decref ";
    json_decref(j);
    //std::cout << " to str ";
    std::string ss = (std::string) s;
    //std::cout << s;
    free(s);

    RestClient::response r = RestClient::post(url,"application/json",ss);

    cout << r.body.c_str() << endl;
    json_t * root;
    if (r.code >= 200 && r.code < 300)
    {
        //cout << r.body << endl;


        json_error_t error;
        root = json_loads(r.body.c_str(), 0, &error);
        if(!root)
        {
            cerr << "error: on line " << error.line << ": " << error.text << endl;
        }

        json_decref(root);

    }
    else
        cerr << "Error: " << r.code << endl;

}

int NewineAPIClient::wine_replace_post(int bottle_index, int disp_id)
{

    std::string url = "192.168.0.1:3000/bottle_holder/reload";

    cout << url << endl;
        
    json_t * j =  json_pack("{s:i, s:i}",
                            "dispenser_id", disp_id,
                            "dispenser_index", bottle_index);


    //std::cout<<" root ";
    char * s = json_dumps(j,0);
    //std::cout << " decref ";
    json_decref(j);
    //std::cout << " to str ";
    std::string ss = (std::string) s;
    //std::cout << s;
    free(s);

    RestClient::response r = RestClient::post(url,"application/json",ss);

    cout << r.body.c_str() << endl;
    json_t * root;
    if (r.code >= 200 && r.code < 300)
    {
        //cout << r.body << endl;


        json_error_t error;
        root = json_loads(r.body.c_str(), 0, &error);
        if(!root)
        {
            cerr << "error: on line " << error.line << ": " << error.text << endl;
        }

        json_decref(root);

        cout << "Wine replaced successfully." << endl;

    }
    else
        cerr << "Error: " << r.code << endl;

}

int NewineAPIClient::wine_days(int bottle_index, int disp_id)
{

    std::string url = "192.168.0.1:3000/bottle_holder/days_bottle_change";

    //cout << url << endl;
        
    json_t * j =  json_pack("{s:i, s:i}",
                            "dispenser_id", disp_id,
                            "dispenser_index", bottle_index);


    //std::cout<<" root ";
    char * s = json_dumps(j,0);
    //std::cout << " decref ";
    json_decref(j);
    //std::cout << " to str ";
    std::string ss = (std::string) s;
    //std::cout << s;
    free(s);

    RestClient::response r = RestClient::post(url,"application/json",ss);
    //std::cout << r.body.c_str() << std::endl;

  if(r.code >= 200 && r.code < 300)
    {
        json_error_t error;
        json_t * root = json_loads(r.body.c_str(), 0, &error);
        if(!root)
        {
            cout << "error: on line " << error.line << ": " << error.text << endl;
            return 0;
        }

        int days;
        json_unpack(root,"{s:i}","days",&days);
        char *s = json_dumps(root, 0);
        //std::cout << std::string(s) << std::endl;

        return days;
    }
    else
    {
        cerr << "Error: " << r.code << endl;
        return 0;
    }

}
void NewineAPIClient::wine_list_post(int wine_id, int bottle_index, int disp_id)
{
    std::string url = api_server_url + api_wine_selection_route;

    cout << url << endl;
        
    json_t * j =  json_pack("{s:i, s:i, s:i}",
                            "wine_id", wine_id ,
                            "dispenser_id", disp_id,
                            "dispenser_index", bottle_index);


    //std::cout<<" root ";
    char * s = json_dumps(j,0);
    //std::cout << " decref ";
    json_decref(j);
    //std::cout << " to str ";
    std::string ss = (std::string) s;
    //std::cout << s;
    free(s);

    RestClient::response r = RestClient::post(url,"application/json",ss);

    cout << r.body.c_str() << endl;
    json_t * root;
    if (r.code >= 200 && r.code < 300)
    {
        //cout << r.body << endl;


        json_error_t error;
        root = json_loads(r.body.c_str(), 0, &error);
        if(!root)
        {
            cerr << "error: on line " << error.line << ": " << error.text << endl;
        }

        json_decref(root);

        cout << "Wine id: " << wine_id << " in position: " << bottle_index << " posted to server successfully." << endl;

    }
    else
        cerr << "Error: " << r.code << endl;

}




NewineAPIUser * NewineAPIClient::users_get(std::string uid)
{
    NewineAPIUser * user = NULL;
    std::string url = api_server_url + api_users_route + "/" + uid + ".json";


    cout << url << endl;

    RestClient::response r = RestClient::get(url);
    //cout << r.code << endl;
    json_t * root;
    if (r.code >= 200 && r.code < 300)
    {
        //cout << r.body << endl;


        json_error_t error;
        root = json_loads(r.body.c_str(), 0, &error);
        if(!root)
        {
            cerr << "error: on line " << error.line << ": " << error.text << endl;
            return NULL;
        }

        user = new NewineAPIUser(root);
        if(!user->valid_user)
        {
            delete user;
            user = NULL;
        }
        json_decref(root);

        //cout << "User: " << user.name << ", " << user.credit << ", " << user.id << ", "<< user.uid << endl;

    }
    else
        cerr << "Error: " << r.code << endl;


    return user;
}

NewineAPIServing * NewineAPIClient::servings_post(NewineAPIServing * serving_in)
{
    NewineAPIServing * serving_out = NULL;
    std::string url = api_server_url + api_servings_route + ".json";

    cout << url << endl;

    RestClient::response r = RestClient::post(url,"application/json",serving_in->to_json());

    cout << r.body.c_str() << endl;
    json_t * root;
    if (r.code >= 200 && r.code < 300)
    {
        //cout << r.body << endl;


        json_error_t error;
        root = json_loads(r.body.c_str(), 0, &error);
        if(!root)
        {
            cerr << "error: on line " << error.line << ": " << error.text << endl;
            return NULL;
        }

        serving_out = new NewineAPIServing(root);
        if(!serving_out->valid_serving)
        {
            delete serving_out;
            serving_out = NULL;
        }
        json_decref(root);

        //cout << "User: " << user.name << ", " << user.credit << ", " << user.id << ", "<< user.uid << endl;

    }
    else
        cerr << "Error: " << r.code << endl;


    return serving_out;
}

bool NewineAPIClient::temperature_post(int tmp_ctrl, double temp, int disp_id)
{
    json_t * j =  json_pack("{s:i, s:f, s:i}",
                            "dispenser_id", disp_id ,
                            "temperature", temp,
                            "dispenser_index", tmp_ctrl);

    

    char * s = json_dumps(j,0);
    json_decref(j);
    //std::cout << " to str ";
    std::string ss = (std::string) s;
    //std::cout << s;
    free(s);

    std::string url = api_server_url + api_temperature_route + ".json";

    cout << url << endl;

    RestClient::response r = RestClient::post(url,"application/json",ss);
    cout << r.body << endl;
    return (r.code >= 200 && r.code < 300);
}