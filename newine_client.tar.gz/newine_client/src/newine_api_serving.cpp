#include "newine_api_serving.hpp"
#include <iostream>
NewineAPIServing::NewineAPIServing(json_t * srv)
{


    const char * juid;
    int jbottle_index, jserving_index, jvolume, jdisp_id;
    double jprice, jcredit;

    int jvalid;


    valid_serving = json_is_boolean(json_object_get(srv,"valid_serving"));

    if(valid_serving)
    {
        json_unpack(srv,"{s:b}","valid_serving",&jvalid);

        valid_serving = (valid_serving && (jvalid != 0));

        if (valid_serving)
        {
            json_unpack(srv,"{s:i, s:s, s:i, s:i, s:i, s:f, s:f}","dispenser_id", &jdisp_id ,"uid", &juid, "bottle_index", &jbottle_index,
                            "serving_index", &jserving_index, "volume", &jvolume, "price", &jprice,
                            "remaining_credit", &jcredit);

            uid = (std::string) juid;

            bottle_index = jbottle_index;
            serving_index = jserving_index;
            volume = jvolume;
            price = jprice;
            remaining_credit = jcredit;
            dispenser_id = jdisp_id;
        }
    }

}

NewineAPIServing::NewineAPIServing(int disp_id, std::string uid_in, int bottle_index_in, int serving_index_in, double price_in, int volume_in, double credit)
{
    dispenser_id = disp_id;
    uid = uid_in;
    bottle_index = bottle_index_in;
    serving_index = serving_index_in;
    price = price_in;
    volume = volume_in;
    remaining_credit = credit;
    valid_serving = true;
}

json_t * NewineAPIServing::to_json_object(void)
{
    //std::cout << "packing";
    json_t * s =  json_pack("{s:i, s:s, s:i, s:i, s:i, s:f, s:f, s:b}",
                            "dispenser_id", dispenser_id ,
                            "uid", uid.c_str(),
                            "bottle_index", bottle_index,
                            "serving_index", serving_index,
                            "volume", volume,
                            "price", price,
                            "remaining_credit", remaining_credit,
                            "valid_serving", valid_serving);
    //std::cout<<" root ";
    json_t * root = json_pack("{s:o}","serving", s);

    return root;
}

std::string NewineAPIServing::to_json(void)
{
    json_t * j = to_json_object();
    //std::cout << "dumping " << (int)j;
    char * s = json_dumps(j,0);
    //std::cout << " decref ";
    json_decref(j);
    //std::cout << " to str ";
    std::string ss = (std::string) s;
    //std::cout << s;
    free(s);
    return ss;
}