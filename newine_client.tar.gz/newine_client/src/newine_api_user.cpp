#include "newine_api_user.hpp"

NewineAPIUser::NewineAPIUser(json_t * usr)
{


    const char * jname, * juid, *jclient_type;
    int jcan_clean, jcan_detach, jcan_set_temp;

    int jvalid;


    valid_user = json_is_boolean(json_object_get(usr,"valid_user"));

    if(valid_user)
    {
        json_unpack(usr,"{s:b}","valid_user",&jvalid);

        valid_user = (valid_user && (jvalid != 0));

        if (valid_user)
        {
            json_unpack(usr,"{s:s, s:s, s:i, s:f, s:b, s:b, s:b, s:s}", "uid", &juid, "name", &jname,
                            "id", &id, "credit", &credit, "can_clean", &jcan_clean, "can_detach", &jcan_detach, "can_set_temp", &jcan_set_temp);

            uid = (std::string) juid;
            name = (std::string) jname;

            if (name == "TECH_USER")
            {
                type = UserType::TECH_USER;
            }
            else if (name == "TESTING_USER")
            {
                type = UserType::TESTING_USER;
            }
            else
            {
                type = UserType::REGULAR;
            }


            can_clean = (jcan_clean != 0);
            can_detach = (jcan_detach != 0);
            can_set_temp = (jcan_set_temp != 0);
        }
    }

}