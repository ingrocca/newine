#include "nfc_reader.hpp"
#include <nfc/nfc.h>

//TODO
void NFCReader::initialize(std::condition_variable *event_not)
{
    event_notifier = event_not;
    card_presence = false;

    pnd = NULL;
    context = NULL;

    hardware_initialized = false;

    init_attempts = 0;

    nfc_reset_pin.initialize("115");
    nfc_reset_pin.turn_off(); // This outputs a 1 - the reset pin is active low (0 to reset), so this works fine

    shutdown = new std::atomic<bool>(false);

    listener = new std::thread([this](){
        card_listener();
    });
}

bool NFCReader::setup_hardware(void)
{
    bool success = false;

    std::cout << "Attempting to init NFC board." << std::endl;
    std::cout << "Attempt N�" << init_attempts << std::endl;

    if (pnd != NULL)
    {
        // Close NFC device
        nfc_close(pnd);
        pnd = NULL;
    }
    if (context != NULL)
    {
        // Release the context
        nfc_exit(context);
        context = NULL;
    }

    if (init_attempts > 5)
    {
        std::cout << "Failed after 5 attempts, reseting device." << std::endl;
        init_attempts = 0;
        reset_nfc();
    }

    // Initialize libnfc and set the nfc_context
    nfc_init(&context);
    if (context == NULL)
    {
        std::cerr << "Unable to init libnfc (malloc)" << std::endl;
    }
    else
    {
        pnd = nfc_open(context, "pn532_i2c:/dev/i2c-1");
        if (pnd == NULL)
        {
            std::cerr << "ERROR: Unable to open NFC device." << std::endl;
            std::cerr << "Retrying..." << std::endl;
            pnd = nfc_open(context, "pn532_i2c:/dev/i2c-1");
        }
        // Set opened NFC device to initiator mode
        if(pnd!=NULL)
        {
            if(nfc_initiator_init(pnd) < 0)
            {
                nfc_perror(pnd, "nfc_initiator_init");
                // Close NFC device
                nfc_close(pnd);
                pnd = NULL;
                // Release the context
                nfc_exit(context);
                context = NULL;
            }
            // NFC initialized successfully
            else
            {
                std::cout << "NFC Device initialized." << std::endl;
                success = true;
            }
        }
        else
        {
            std::cerr << "It wasn't effective." << std::endl;
            nfc_exit(context);
            context = NULL;
        }
    }

    if (success)
    {
        init_attempts = 0;
    }
    else
    {
        ++init_attempts;
    }

    return success;
}

void NFCReader::reset_nfc(void)
{
    std::chrono::milliseconds sleep_time(500);

    nfc_reset_pin.turn_on();

    std::this_thread::sleep_for(sleep_time);

    nfc_reset_pin.turn_off();

    std::this_thread::sleep_for(sleep_time);
}


void NFCReader::stop(void)
{
    *shutdown = true;
    listener -> join();
    // Close NFC device
    nfc_close(pnd);
    // Release the context
    nfc_exit(context);
    delete shutdown;
    delete listener;
}

bool NFCReader::card_present(void)
{
    lock.lock();
    bool cp = card_presence;
    lock.unlock();
    return cp;
}

void NFCReader::flag_down(void)
{
    lock.lock();
    card_presence = false;
    lock.unlock();
}

std::string NFCReader::get_user_id(void)
{
    lock.lock();
    std::string cd = card_data;
    lock.unlock();
    return cd;
}

void NFCReader::card_listener(void)
{
    while(!*shutdown)
    {
        if (hardware_initialized)
        {
            // Poll for a ISO14443A (MIFARE) tag
            int result_code = nfc_initiator_poll_target(pnd, &nmMifare,1, 1,1, &nt);
            if (result_code > 0) // nfc_initiator_poll_target returns the count of polled targets
            {
                card_presence = true;
                card_data.clear();
                for(int i=0; i<nt.nti.nai.szUidLen; i++)
                {
                    char usr_id_i[3];
                    sprintf(usr_id_i,"%02x",nt.nti.nai.abtUid[i]);
                    card_data+=usr_id_i;
                }
                event_notifier->notify_one();
            }
            else if (result_code < 0)
            {
                int last_error = nfc_device_get_last_error(pnd);
                if (last_error != NFC_SUCCESS) {
                    nfc_perror(pnd, "Error while polling");
                    hardware_initialized = false;
                }
            }
        }
        else
        {
            if (setup_hardware())
            {
                hardware_initialized = true;
            }
        }

        // wait for refresh time completion
        std::chrono::milliseconds sleep_time( NFC_REFRESH_TIME );
        std::this_thread::sleep_for(sleep_time);
    }

    return;
}
 
