#include "nfc_reader.hpp"
#include <chrono>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <iostream>

using namespace std;


bool wait_for_wakeup_signal(chrono::milliseconds timeout, function<bool (void)> test);
std::condition_variable evnt_notifier;
std::mutex lck;
int main (void)
{
    std::atomic<bool> * shutdown;
    shutdown = new std::atomic<bool>(false);

    NFCReader nfc_board;
    nfc_board.initialize(&evnt_notifier);

    cout << "Waiting for NFC tag" << endl;
    while(!*shutdown)
    {
        chrono::milliseconds timeout(500);
        if(wait_for_wakeup_signal(timeout, [&](){return nfc_board.card_present(); }))
        {
            string user_id = nfc_board.get_user_id();
            //string uid = nfc_board.get_user_id();
            cout << "NFC tag found: UID = " << user_id << endl << endl;

        }
    }

    return 0;
}

bool wait_for_wakeup_signal(chrono::milliseconds timeout, function<bool (void)> test)
{

    // Use condition_variable to block. Should be unlocked from nfc_board or configuration
    unique_lock<mutex> l(lck);

    return evnt_notifier.wait_for(l,timeout,test);

}