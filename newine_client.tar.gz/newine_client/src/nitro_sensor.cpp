#include "nitro_sensor.hpp"
#include <iostream>
#include <fstream>
#include <streambuf>
#include <cmath>

#define SENSORS_DIR std::string("/sys/devices/ocp.3/helper.14/")

#define DEVICE_NAME_START std::string("28-")

NitroSensor::NitroSensor(std::string adc, int threshold)
{
    this->adc = adc;
    this->threshold = threshold;
    this->recharged = false;
    this->n_samples = 0;
    this->average = 0;


    // We can't sense wether we're above or below the low nitro mark, only when we're directly over it.
    // Therefore, we assume we've above the nitro mark, until we measure being over it, and from that point on
    // we ignore the reading, and assume we're below the mark.
    std::ifstream n("/home/newine/newine_client/nitro");
    std::string state;
    getline(n, state);
    n.close();
    std::cout << "Checking nitro level...";
    if(!state.compare("OK"))
    {
        above_mark = true;
        std::cout << "Nitro OK" << std::endl;
    }
    else
    { 
        above_mark = false;
        std::cout << "Nitro not OK" << std::endl;
    }
}

bool NitroSensor::update_value(void)
{


    std::cout << "Checking nitro level..." << std::endl;
    if(recharged)
    {
        above_mark = true;
        std::ofstream n("/home/newine/newine_client/nitro");
        n << "OK";
        n.close();
        recharged = false;
        n_samples = 0;
        std::cout << "Nitro recharged" << std::endl;
    }

    if (!above_mark)
    {
        std::cout << "Nitro not OK" << std::endl;
        return false;
    }

 

    std::ifstream t((SENSORS_DIR + adc).c_str());
    std::string contents((std::istreambuf_iterator<char>(t)),
        std::istreambuf_iterator<char>());

    int raw_measurement = std::stoi(contents);

    if(n_samples<5)
    {
        samples[n_samples] = raw_measurement;
        n_samples++;
    }
    else
    {
        for(int i=0;i<4;i++)
        {
            samples[i] = samples[i+1];
            std::cout << std::to_string(samples[i]) + " ";
        }

        samples[4] = raw_measurement;
        average = 0;
        std::cout << samples[4] << std::endl;

        for(int i=0;i<5;i++)
        {
            average += samples[i];
        }
        average = average/5;


        if (abs(average - raw_measurement)*100/average > threshold)
        {
            std::cout << "Detected " + std::to_string(abs(average - raw_measurement)*100/average) + "% variation when checking the nitro sensor."<< std::endl;
            std::ofstream n("/home/newine/newine_client/nitro");
            n << "LOW";
            n.close();
            std::cout << "Nitro not OK" << std::endl;
            above_mark = false;
            this->value = false;
            return false;
        }
    }

    return true;
}

void NitroSensor::recharge(void)
{
    recharged = true;
}
bool NitroSensor::get_value(void)
{
    std::ifstream n("/home/newine/newine_client/nitro");
    std::string state;
    getline(n, state);
    n.close();
    if(!state.compare("OK"))
    {
        return true;
    }
    else
    { 
        return false;
    }
}