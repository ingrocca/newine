#include "relay.hpp"

void Relay::initialize(std::string relay_gpio)
{
    gpio = relay_gpio;
    std::ofstream expor("/sys/class/gpio/export");
    expor << gpio;
    expor.close();
    std::ofstream dir("/sys/class/gpio/gpio" + gpio + "/direction");
    dir << "out";
    dir.close();
    turn_off();
}

void Relay::stop(void)
{
    std::ofstream expor("/sys/class/gpio/unexport");
    expor << gpio;
    expor.close();
}

void Relay::turn_on(void)
{
	std::ofstream gval("/sys/class/gpio/gpio" + gpio + "/value");
	gval << "0";
	gval.close();
}

void Relay::turn_off(void)
{
	std::ofstream gval("/sys/class/gpio/gpio" + gpio + "/value");
	gval << "1";
	gval.close();
}
