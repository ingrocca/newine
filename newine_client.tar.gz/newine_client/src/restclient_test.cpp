#include "restclient.hpp"
#include "newine_api_user.hpp"
#include "newine_api_client.hpp"
#include <iostream>
#include <jansson.h>

using namespace std;
int main (void)
{
    NewineAPIClient client;
    cout << "First test: NewineAPIUser, RestClient and jansson" << endl;
    RestClient::response r = RestClient::get("localhost:9393/users/abcd.json");
    cout << r.code << endl;
    json_t * root;
    if (r.code >= 200 && r.code < 300)
    {
        cout << r.body << endl;


        json_error_t error;
        root = json_loads(r.body.c_str(), 0, &error);
        if(!root)
        {
            cerr << "error: on line " << error.line <<": " << error.text << endl;
            return 1;
        }

        NewineAPIUser user(root);

        cout << "User: " << user.name << ", " << user.credit << ", " << user.id << ", "<< user.uid << endl;
        json_decref(root);
    }

    cout << "Second test: NewineAPIClient" << endl;



    std::string uid("abcd");
    NewineAPIUser * current_user = client.users_get(uid);
    if(current_user!=NULL)
        cout << "User: " << current_user->name << ", " << current_user->credit << ", " << current_user->id << ", "<< current_user->uid
        <<", " << current_user -> can_clean << endl;
    else
        cout << "Could not get user" << endl;

    cout << "Third test: an invalid user" << endl;
    std::string uid2("sarasa");
    NewineAPIUser * current_user2 = client.users_get(uid2);
    if(current_user2!=NULL)
        cout << "User: " << current_user2->name << ", " << current_user2->credit << ", " << current_user2->id << ", "<< current_user2->uid
        <<", " << current_user2 -> can_clean << endl;
    else
        cout << "Could not get user" << endl;


    if(current_user!=NULL)
        delete current_user;
    if(current_user2!=NULL)
        delete current_user2;

    return 0;
}