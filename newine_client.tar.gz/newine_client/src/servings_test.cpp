#include "restclient.hpp"
#include "newine_api_user.hpp"
#include "newine_api_client.hpp"
#include "newine_api_serving.hpp"
#include <iostream>
#include <jansson.h>

using namespace std;
int main (void)
{
    cout << "Constructor with all params" << endl;
    string uid("ca910c6d");
    NewineAPIServing serving(7,uid, 2, 1, 2.5, 200, 5.5);

    cout << "dispenser_id: " << serving.dispenser_id << ", uid: " << serving.uid << ", bottle: " << serving.bottle_index << ", option: " << serving.serving_index
    << ", price: " << serving.price << ", volume: " << serving.volume << ", credit: " << serving.remaining_credit << endl;

    cout << "to_json" << endl;

    cout << serving.to_json() << endl;

    cout << "Constructor from JSON object" << endl;

    json_t * j = serving.to_json_object();

    json_t * s = json_object_get(j,"serving");

    NewineAPIServing serving2(s);
    json_decref(j);

    cout << "dispenser_id: " << serving2.dispenser_id << "uid: " << serving2.uid << ", bottle: " << serving2.bottle_index << ", option: " << serving2.serving_index
    << ", price: " << serving2.price << ", volume: " << serving2.volume << ", credit: " << serving2.remaining_credit << endl;

    cout << "to_json"<<endl;

    cout << serving2.to_json() << endl;

    cout << "API post" << endl;
    NewineAPIClient api;

    NewineAPIServing * serving3 =  api.servings_post(&serving);

    if (serving3 != NULL)
    {
        if(serving3 -> valid_serving)
        {
            cout << serving3 -> to_json() << endl;
            cout << "dispenser_id: " << serving3 -> dispenser_id << "uid: " << serving3 -> uid << ", bottle: " << serving3 -> bottle_index << ", option: " << serving3 -> serving_index
            << ", price: " << serving3 -> price << ", volume: " << serving3 -> volume << ", credit: " << serving3 -> remaining_credit << endl;
        }
        else
            cout << "Serving is invalid" << endl;
    }
    else
        cout << "Serving is null" << endl;

    return 0;

}