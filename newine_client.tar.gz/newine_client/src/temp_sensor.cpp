#include "temp_sensor.hpp"

#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <iostream>
#include <fstream>
#include <streambuf>
#include <cmath>

#define SENSORS_DIR std::string("/sys/devices/w1_bus_master1/")

#define DEVICE_NAME_START std::string("28-")

TemperatureSensor::TemperatureSensor(void)
{
    sensor_filename = "";
}

bool TemperatureSensor::update_value(void)
{
    if (!get_sensor_filename())
    {
        return false;
    }

    std::ifstream t((SENSORS_DIR + sensor_filename + "/w1_slave").c_str());
    std::string contents((std::istreambuf_iterator<char>(t)),
        std::istreambuf_iterator<char>());

    std::string start_of_value = "t=";
    int temp_milicelsius = std::stoi(contents.substr(contents.find(start_of_value) + start_of_value.length()));
    this->value = round(temp_milicelsius / 1000.0);

    return true;
}

bool TemperatureSensor::get_sensor_filename(void)
{
    if (sensor_filename == "")
    {
        std::vector<std::string> files;
        getdir(SENSORS_DIR, files);
        for (auto & file : files)
        {
            if (file.find(DEVICE_NAME_START) == 0)
            {
                sensor_filename = file;
                std::cout << "Found temperature sensor: " << sensor_filename << std::endl;
                break;
            }
        }
    }

    return (sensor_filename != "");
}

bool TemperatureSensor::getdir(std::string dir, std::vector<std::string> &files)
{
    DIR *dp;
    struct dirent *dirp;
    if((dp  = opendir(dir.c_str())) == NULL) {
        std::cout << "Error(" << errno << ") opening " << dir << std::endl;
        return false;
    }

    while ((dirp = readdir(dp)) != NULL) {
        files.push_back(std::string(dirp->d_name));
    }
    closedir(dp);

    return true;
}