#include "tested_station.hpp"
#include <sys/time.h>
#include <iostream>

#define OPENING_DURATION_MS 1500
#define OPEN_DURATION_MS 500
#define CLOSING_DURATION_MS OPENING_DURATION_MS

TestedStation::TestedStation(int station_index, int n_stations)
{
    this->station_index = station_index;
    this->n_stations = n_stations;

    limit_switch_working = true;
    leak_found = false;
    tests_performed = 0;

    board_under_test = NULL;
    test_status = TestStatus::DONE;
}

bool TestedStation::should_perform_new_test(int target_tests)
{
    return (!is_faulty() && (tests_performed < target_tests));
}

bool TestedStation::is_faulty(void)
{
    return (!limit_switch_working || leak_found);
}

void TestedStation::show_testing_data(LCDisplay *lcd_display)
{
    lcd_display->show_testing_data(tests_performed, limit_switch_working, leak_found);
}

void TestedStation::start_new_test(IOShield *board_under_test)
{
    if (!is_faulty())
    {
        this->board_under_test = board_under_test;
        test_status = TestStatus::CLOSED;
    }
}

bool TestedStation::current_test_done(void)
{
    return test_status == TestStatus::DONE;
}

void TestedStation::test_first_step(void)
{
    // This is where we act on the motor

    if (test_status == TestStatus::CLOSED_DONE)
    {
        open_cmd_time = get_time_ms();
        board_under_test->set_press_motor(station_index, IOShield::BACKWARD);
        test_status = TestStatus::OPENING;
    }
    else if (test_status == TestStatus::OPENING_DONE)
    {
        halt_open_cmd_time = get_time_ms();
        board_under_test->set_press_motor(station_index, IOShield::STOP);
        test_status = TestStatus::OPEN;
    }
    else if (test_status == TestStatus::OPEN_DONE)
    {
        close_cmd_time = get_time_ms();
        board_under_test->set_press_motor(station_index, IOShield::FORWARD);
        test_status = TestStatus::CLOSING;
    }
    else if (test_status == TestStatus::CLOSING_DONE)
    {
        halt_close_cmd_time = get_time_ms();
        board_under_test->set_press_motor(station_index, IOShield::STOP);
        test_status = TestStatus::DONE;

        tests_performed += 1;
    }
}

void TestedStation::test_second_step(void)
{
    // This is where we read the sensors

    unsigned char data = board_under_test->non_blocking_get(station_index + n_stations);
    bool flowmeter = FLOWMETER_STATUS(data);
    bool limit_switch = LIMIT_SWITCH_STATUS(data);

    if (detect_limit_switch_fault(limit_switch))
    {
        limit_switch_working = false;
        test_status = TestStatus::CLOSING_DONE;
    }
    else if (detect_leak(flowmeter))
    {
        leak_found = true;
        test_status = TestStatus::CLOSING_DONE;
    }
    else
    {
        if (test_status == TestStatus::CLOSED)
        {
            test_status = TestStatus::CLOSED_DONE;
        }
        else if (test_status == TestStatus::OPENING)
        {
            if ((get_time_ms() - open_cmd_time) > OPENING_DURATION_MS)
            {
                test_status = TestStatus::OPENING_DONE;
            }
        }
        else if (test_status == TestStatus::OPEN)
        {
            if ((get_time_ms() - halt_open_cmd_time) > OPEN_DURATION_MS)
            {
                test_status = TestStatus::OPEN_DONE;
            }
        }
        else if (test_status == TestStatus::CLOSING)
        {
            if (((get_time_ms() - close_cmd_time) > CLOSING_DURATION_MS) || flowmeter)
            {
                test_status = TestStatus::CLOSING_DONE;
            }
        }
    }
}

bool TestedStation::detect_limit_switch_fault(bool limit_switch)
{
    bool detected_faulty_condition = false;

    if ((test_status == TestStatus::CLOSED) || (test_status == TestStatus::CLOSED_DONE))
    {
        if (!limit_switch)
        {
            detected_faulty_condition = true;
        }
    }
    else if ((test_status == TestStatus::OPENING_DONE) || (test_status == TestStatus::OPEN) || (test_status == TestStatus::OPEN_DONE))
    {
        if (limit_switch)
        {
            detected_faulty_condition = true;
        }
    }

    if (detected_faulty_condition && suspect_faulty_limit_switch)
    {
        std::cout << "The limit switch is faulty on station " << station_index << std::endl;
        return true;
    }

    suspect_faulty_limit_switch = detected_faulty_condition;

    return false;
}

bool TestedStation::detect_leak(bool flowmeter)
{
    if (test_status == TestStatus::CLOSED)
    {
        initial_flowmeter_status = flowmeter;
        previous_flowmeter_status = flowmeter;
        last_pulse_time = 0;
    }
    else
    {
        if (flowmeter != previous_flowmeter_status)
        {
            bool detected_close_pulses = false;

            if (previous_flowmeter_status != initial_flowmeter_status) // This is a new pulse
            {
                std::cout << "Detected a flowmeter pulse on station " << station_index << std::endl;

                long now = get_time_ms();
                if ((now - last_pulse_time) < 200) // We accept pulses, but only if they are far apart
                {
                    std::cout << "Detected two close flowmeter pulses on station " << station_index << ", we're leaking!" << std::endl;
                    detected_close_pulses = true;
                }

                last_pulse_time = now;
            }

            previous_flowmeter_status = flowmeter;

            return detected_close_pulses;
        }
    }

    return false;
}

long TestedStation::get_time_ms(void)
{
    timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return ts.tv_sec * 1000 + ts.tv_nsec / (1000 * 1000);
}

void TestedStation::load(json_t *j_val)
{
    limit_switch_working = json_integer_value(json_object_get(j_val, "limit_switch_working")) != 0;
    leak_found = json_integer_value(json_object_get(j_val, "leak_found")) != 0;
    tests_performed = json_integer_value(json_object_get(j_val, "tests_performed"));
}

void TestedStation::save(json_t *j_val)
{
    json_object_set_new(j_val, "limit_switch_working", json_integer(limit_switch_working ? 1 : 0));
    json_object_set_new(j_val, "leak_found", json_integer(leak_found ? 1 : 0));
    json_object_set_new(j_val, "tests_performed", json_integer(tests_performed));
}