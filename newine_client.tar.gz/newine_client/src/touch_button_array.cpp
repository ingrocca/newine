#include "touch_button_array.hpp"

void TouchButtonArray::initialize(IOBoard * brd,unsigned int brd_offst,unsigned int n_bttns, std::atomic<bool> * pressd, std::condition_variable *event_not, bool neg_logic, int get_offset)
{
    board = brd;
    board_offset = brd_offst;
    n_buttons = n_bttns;
    pressed = pressd;
    negative_logic = neg_logic;
    event_notifier = event_not;
    this->get_offset = get_offset;

    t_state_transitions[TOUCH_IDLE] = &TouchButtonArray::t_idle;
    t_state_transitions[BUTTON_PRESSED] = &TouchButtonArray::t_button_pressed;
    t_state_transitions[SLIDE_RIGHT] = &TouchButtonArray::t_slide_right;
    t_state_transitions[SLIDE_LEFT] = &TouchButtonArray::t_slide_left;
    t_state_transitions[ALL_PRESSED] = &TouchButtonArray::t_all_pressed;
    current_state = TOUCH_IDLE;
    previous_state = current_state;
    last_input = NO_BUTTON_PRESSED;
    touch_event.state = touch_state;
    touch_event.button = last_input;
    n_iter = 0;

    shutdown = new std::atomic<bool>(false);

    listener = new std::thread([this](){
        listener_task();
    });
}

void TouchButtonArray::stop(void)
{
    *shutdown = true;
    listener -> join();
    delete shutdown;
    delete listener;
}

void TouchButtonArray::listener_task(void)
{
    while(!*shutdown)
    {
        unsigned char input;

        input = board->async_get(board_offset + get_offset);

        if(negative_logic)
        {
            input = ~input;
        }
        input &= ((1<<n_buttons)-1);    //take only the last (n_buttons) bits

        //translate mask type data to an arithmetic value
        unsigned char pressed_button = NO_BUTTON_PRESSED;
        if(input != 0)
        {
            if(input == ((1<<n_buttons)-1))
            {
                pressed_button = ALL_BUTTON_PRESSED;
            }
            else
            {
                for(unsigned char i=0; i<(n_buttons); i++)
                {
                    if(input == 1<<i)
                    {
                        pressed_button = i;
                    }
                }
            }
        }

        //touch pattern recognition state machine
        previous_state = current_state;
        current_state = (this->*(t_state_transitions[current_state]))(pressed_button);

        // wait for refresh time completion
        std::chrono::milliseconds sleep_time( BUTTONS_REFRESH_TIME );
        std::this_thread::sleep_for(sleep_time);

    }
}


TouchState TouchButtonArray::t_idle(unsigned char pressed_button)
{
    switch(pressed_button)
    {
        case NO_BUTTON_PRESSED:
            return TOUCH_IDLE;
        case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
            last_input = pressed_button;
            n_iter++;
            return BUTTON_PRESSED;
        case ALL_BUTTON_PRESSED:
            n_iter++;
            return ALL_PRESSED;
        default:
            return TOUCH_IDLE;
    }
}
TouchState TouchButtonArray::t_button_pressed(unsigned char pressed_button)
{
    if(n_iter >= BUTTONS_MAX_ITER)
    {
        if(pressed_button != NO_BUTTON_PRESSED)
        {
            //elapsed time equals or exceeds timeout -> notify event
            *pressed = true;
            touch_event.state = BUTTON_PRESSED;
            touch_event.button = pressed_button;
            std::cout<< "Button " << (int)last_input << "  pressed at board: " << board_offset << " with " << n_buttons << " buttons."<< std::endl;
            event_notifier->notify_one();
        }
        //Reset state machine
        last_input = NO_BUTTON_PRESSED;
        n_iter = 0;
        return TOUCH_IDLE;
    }

    if(pressed_button == ALL_BUTTON_PRESSED)
    {
        n_iter++;
        return ALL_PRESSED;
    }
    else if( (pressed_button != NO_BUTTON_PRESSED) && (pressed_button != last_input) )
    {
        if( (pressed_button == last_input+1) && (last_input == 0) )
        {
            last_input = pressed_button;
            n_iter++;
            return SLIDE_RIGHT;
        }
        else if( (pressed_button == last_input-1) && (last_input == n_buttons-1) )
        {
            last_input = pressed_button;
            n_iter++;
            return SLIDE_LEFT;
        }
        else
        {
            //Pattern error -> reset state machine
            last_input = NO_BUTTON_PRESSED;
            n_iter = 0;
            return TOUCH_IDLE;
        }
    }
    else
    {
        //Evaluar la posibilidad de reiniciar si no se detecta nada
        n_iter++;
        return BUTTON_PRESSED;
    }
}
TouchState TouchButtonArray::t_slide_right(unsigned char pressed_button)
{
    if(n_iter > BUTTONS_SLIDE_MAX_ITER)
    {
        //Reset state machine
        last_input = NO_BUTTON_PRESSED;
        n_iter = 0;
        return TOUCH_IDLE;
    }

    if(pressed_button == ALL_BUTTON_PRESSED)
    {
        n_iter++;
        return ALL_PRESSED;
    }
    else if( (pressed_button != NO_BUTTON_PRESSED) && (pressed_button != last_input) )
    {
        if(pressed_button == last_input+1)
        {
            if(pressed_button == n_buttons-1)
            {
                // SLIDE_RIGHT COMPLETED SUCCESSFULLY
                *pressed = true;
                touch_event.state = SLIDE_RIGHT;
                touch_event.button = pressed_button;
                std::cout<< "SLIDE_RIGHT at board" << board_offset << std::endl;

                //Reset state machine
                last_input = NO_BUTTON_PRESSED;
                n_iter = 0;
                event_notifier->notify_one();
                return TOUCH_IDLE;
            }
            else
            {
                // SLIDE_RIGHT in progress
                last_input = pressed_button;
                n_iter++;
                return SLIDE_RIGHT;
            }
        }
        else
        {
            //Pattern error -> reset state machine
            last_input = NO_BUTTON_PRESSED;
            n_iter = 0;
            return TOUCH_IDLE;
        }
    }
    else
    {
        n_iter++;
        return SLIDE_RIGHT;
    }
}
TouchState TouchButtonArray::t_slide_left(unsigned char pressed_button)
{
    if(n_iter > BUTTONS_SLIDE_MAX_ITER)
    {
        //Reset state machine
        last_input = NO_BUTTON_PRESSED;
        n_iter = 0;
        return TOUCH_IDLE;
    }

    if(pressed_button == ALL_BUTTON_PRESSED)
    {
        n_iter++;
        return ALL_PRESSED;
    }
    else if( (pressed_button != NO_BUTTON_PRESSED) && (pressed_button != last_input) )
    {
        if(pressed_button == last_input-1)
        {
            if(pressed_button == 0)
            {
                // SLIDE_LEFT COMPLETED SUCCESSFULLY
                *pressed = true;
                touch_event.state = SLIDE_LEFT;
                touch_event.button = pressed_button;
                std::cout<< "SLIDE_LEFT at board" << board_offset << std::endl;

                //Reset state machine
                last_input = NO_BUTTON_PRESSED;
                n_iter = 0;
                event_notifier->notify_one();
                return TOUCH_IDLE;
            }
            else
            {
                // SLIDE_LEFT in progress
                last_input = pressed_button;
                n_iter++;
                return SLIDE_LEFT;
            }
        }
        else
        {
            //Pattern error -> reset state machine
            last_input = NO_BUTTON_PRESSED;
            n_iter = 0;
            return TOUCH_IDLE;
        }
    }
    else
    {
        n_iter++;
        return SLIDE_LEFT;
    }
}
TouchState TouchButtonArray::t_all_pressed(unsigned char pressed_button)
{
    n_iter++;

    if(n_iter >= BUTTONS_ALL_HOLD_MAX_ITER)
    {
        //if buttons are touched for BUTTONS_ALL_HOLD_TIMEOUT -> ALL_HOLD
        *pressed = true;
        touch_event.state = ALL_HOLD;
        std::cout<< "ALL BUTTONS HOLD at board "  << board_offset << std::endl;
        event_notifier->notify_one();

        //Reset state machine
        last_input = NO_BUTTON_PRESSED;
        n_iter = 0;
        return TOUCH_IDLE;
    }
    else if(n_iter == BUTTONS_ALL_PRESSED_MAX_ITER)
    {
        //if buttons are hold for between BUTTONS_ALL_PRESSED_TIMEOUT and BUTTONS_ALL_HOLD_TIMEOUT -> ALL_PRESSED
        *pressed = true;
        touch_event.state = ALL_PRESSED;
        std::cout<< "ALL BUTTONS PRESSED at board "  << board_offset << std::endl;
        event_notifier->notify_one();
        return ALL_PRESSED;
    }
    else if( (n_iter > BUTTONS_ALL_PRESSED_MAX_ITER) && (pressed_button == NO_BUTTON_PRESSED) )
    {
        *pressed = true;
        touch_event.state = ALL_PRESSED_RELEASED;

        std::cout<< "ALL BUTTONS RELEASED at board "  << board_offset << std::endl;
        event_notifier->notify_one();

        //Reset state machine
        last_input = NO_BUTTON_PRESSED;
        n_iter = 0;
        return TOUCH_IDLE;
    }
    else if( (n_iter < BUTTONS_ALL_PRESSED_MAX_ITER) && (pressed_button == NO_BUTTON_PRESSED) )
    {
        last_input = NO_BUTTON_PRESSED;
        n_iter = 0;
        return TOUCH_IDLE;
    }
    return ALL_PRESSED;
}


TouchEvent TouchButtonArray::get_event(void)
{
    lock.lock();
    //Clear pressed flag
    *pressed = false;
    TouchEvent event = touch_event;
    touch_event.state = TOUCH_IDLE;
    touch_event.button = NO_BUTTON_PRESSED;
    lock.unlock();
    return event;
}

void TouchButtonArray::clean_event(void)
{
	touch_event.state = TOUCH_IDLE;
}
