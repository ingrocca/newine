#include "io_shield.hpp"
#include "touch_button_array.hpp"
#include <atomic>
#include <chrono>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <iostream>

using namespace std;


bool wait_for_wakeup_signal(chrono::milliseconds timeout, function<bool (void)> test);
std::condition_variable evnt_notifier;
std::mutex lck;
int main (void)
{
    std::atomic<bool> * shutdown;
    shutdown = new std::atomic<bool>(false);

    IOShield io_board(1, 0, 1);
    io_board.initialize();

    std::atomic<bool> * button_pressed;
    button_pressed = new std::atomic<bool>(false);

    //std::thread * listener;
    //listener = new std::thread([&](){ read_input();});

    TouchButtonArray serving_buttons;
    serving_buttons.initialize(&io_board,0,2, button_pressed, &evnt_notifier,1);

    cout << "Waiting for user selection" << endl;
    while(!*shutdown)
    {
        chrono::milliseconds timeout(500);
        if(wait_for_wakeup_signal(timeout, [&](){return (bool)*button_pressed;}))
        {
            TouchEvent event = serving_buttons.get_event();
            switch(event.state)
            {
                case SLIDE_LEFT:
                    cout << "SLIDE LEFT" << endl << endl;
                    break;
                case SLIDE_RIGHT:
                    cout << "SLIDE RIGHT" << endl << endl;
                    break;
                case BUTTON_PRESSED:
                    cout << "Button " << (int)event.button << " pressed" << endl << endl;
                    break;
                case ALL_PRESSED:
                    cout << "All buttons pressed" << endl << endl;
                    break;
            }
        }
        else
        {
            /*
            string sb;
            cin >> sb;
            if(sb[0] == 'q')
                *shutdown = true;
            */
        }

    }

    return 0;
}

bool wait_for_wakeup_signal(chrono::milliseconds timeout, function<bool (void)> test)
{

    // Use condition_variable to block. Should be unlocked from nfc_board or configuration
    unique_lock<mutex> l(lck);

    return evnt_notifier.wait_for(l,timeout,test);

}