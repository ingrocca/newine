#include "wine_server.hpp"

#include <sys/time.h>

// 73 Hz == 1 L/min
// 73 Hz == 16.6 mL/s
// 0.073kHz == 0.0166 mL/ms
// 1kHz == 0.219178 mL/ms -> 0.219178 mL per pulse

// Calibration: 0.24743 mL per puse

#define MAXIMUM_FLOW(whole_pulse_volume) (whole_pulse_volume / 6) // Caused by pulses below 6ms

#define LIMIT_SWITCH_A_MASK (1 << 3)
#define LIMIT_SWITCH_B_MASK (1 << 4)
#define FLOWMETER_MASK (1 << 5)

// The limit switch is active low, so we negate it first
// There are two independent limit switches, and we only require one of them to be pressed to consider the press closed
#define LIMIT_SWITCH_STATUS(data) (!(((~data) & (LIMIT_SWITCH_A_MASK | LIMIT_SWITCH_B_MASK)) == 0x00))

#define FLOWMETER_STATUS(data) (((data) & FLOWMETER_MASK) != 0x00)

#define UPDATE_OVER_SPI_TIMEOUT_MS (500)
#define SHORT_UPDATE_OVER_SPI_TIMEOUT_MS (100)

#define N_LIMIT_SWITCH_SAMPLES 5 // Must be odd!

WineServer::WineServer(int n_bottles, IOShield *io_board)
{
    this->n_bottles = n_bottles;
    this->io_board = io_board;

    limit_switch_working.clear();
    for (int i = 0; i < n_bottles; ++i)
    {
        limit_switch_working.push_back(true); // We assume all limit switches are working
    }
}

void WineServer::initialize_press(int bottle)
{
    io_board->lock_updates();
    selected_bottle = bottle;
    emergencyCloseFromStage(OPEN, false);
    io_board->unlock_updates();
}

bool WineServer::serve_volume(float target_volume, int bottle, float *served)
{
    return serve(target_volume, 0, true, bottle, served);
}

bool WineServer::serve_time(long target_time_ms, int bottle, float *served)
{
    return serve(0, target_time_ms, false, bottle, served);
}

bool WineServer::serve(float target_volume, long target_time_ms, bool volume_mode, int bottle, float *served)
{
    // Asumptions:
    //  - The motor being stuck at the 'open' position, and the machine therefore serving wine indefinitely,
    //    is the worst-case scenario.
    //  - The motor breaking down (due to excessive force against the hose) is also bad news, but tolerable:
    //    that serving unit is simply disabled until the motor is replaced.
    //  - It is likely that the limit switches will fail. In case of failure, it is very likely that they
    //    will fail in the 'closed' position.
    //  - It wouldn't be that weird for the flow measurement to fail: it might get disconnected, the hose
    //    might become loose, or the flowmeter could simply fail.
    //  - It is unlikely for the motor to fail. It'd be weird for it or the relays to break down, or
    //    the wires unplug themselves.
    //
    // Therefore:
    //  - We must prevent the motor from stopping at a position where the hose isn't completely closed, even if
    //    this means possibly breaking down the motor.
    //  - We trust the motor more than we do the limit switches: if we think we've moved the motor backwards, and
    //    the limit switch says otherwise, we assume the limit switch is broken (and tag it as broken).
    //  - We do trust working limit switches, since they help prevent damage to the motor, but must resort to
    //    blindly closing the hose by pushing the motor forward when we think the limit switches aren't working.

    io_board->lock_updates();

    selected_bottle = bottle;
    calibration = config.get(selected_bottle);

    std::cout << "Current calibration: " << std::endl;
    std::cout << "Whole pulse volume: " << calibration.whole_pulse_volume << std::endl;
    std::cout << "Control volume offset: " << calibration.control_volume_offset << std::endl;

    std::cout << "Starting new serving on bottle " << selected_bottle << ".";
    if (volume_mode)
    {
        std::cout << " Volume: " << target_volume << "ml" << std::endl;
    }
    else
    {
        std::cout << " Time: " << target_time_ms << "ms" << std::endl;
    }

    bool serving = true;
    bool success = false; // Only set to true when success is certain

    serve_data.limit_switch = false;
    serve_data.flow = 0;
    serve_data.volume = 0;

    if (limit_switch_working[selected_bottle])
    {
        updateLimitSwitchStatus();
        if (!serve_data.limit_switch)
        {
            std::cout << "Error! We tried to start a new serving on bottle " << selected_bottle << " but the limit switch is not pressed." << std::endl;
            std::cout << "We will now assume the limit switch isn't properly working." << std::endl;
            limit_switch_working[selected_bottle] = false;
        }
        else
        {
            std::cout << "The limit switch is pressed, we can start serving." << std::endl;
        }
    }
    else
    {
        std::cout << "This bottle's limit switch isn't working!" << std::endl;
    }

    ServingStage current_serving_stage = CLOSED;

    float accumulated_volume = 0;
    std::list<float> measured_flows;
    float average_flow = 0;

    long open_cmd_time_ms;
    long open_duration_ms;
    long close_cmd_time_ms;
    long current_time_ms;

    while (serving)
    {
        long update_timeout = current_serving_stage == OPEN ? UPDATE_OVER_SPI_TIMEOUT_MS : SHORT_UPDATE_OVER_SPI_TIMEOUT_MS;
        bool update_result = updateServeData(update_timeout);

        current_time_ms = getTimeMS();

        if (!update_result && (current_serving_stage == OPEN))
        {
            std::cout << "Error! We're supposed to be open, but failed to measure any flow after " << UPDATE_OVER_SPI_TIMEOUT_MS << "ms." << std::endl;
            emergencyCloseFromStage(current_serving_stage);
            serving = false;
            continue;
        }

        // We do an if-elseif chain instead of a switch so that we can break/continue over the outer while loop
        if (current_serving_stage == CLOSED)
        {
            open_cmd_time_ms = getTimeMS();
            io_board->set_press_motor(selected_bottle, IOShield::BACKWARD); // Release hose
            current_serving_stage = OPENING;
            std::cout << "Moting the motor backwards: the hose will now open." << std::endl;
            std::cout << "The motor will halt in " << OPENING_TIMEOUT_MS << " ms." << std::endl;
        }
        else if (current_serving_stage == OPENING)
        {
            // If valid measurements are available, update our served volume estimation
            if (!limit_switch_working[selected_bottle] || !serve_data.limit_switch)
            {
                accumulated_volume += serve_data.volume;
                average_flow = updateAverageFlow(measured_flows, serve_data.flow);
            }

            // The exit condition for the OPENING stage is a hardcoded timeout since the motor started going backwards
            open_duration_ms = current_time_ms - open_cmd_time_ms; // This needs to be kept updated (it is used in the closing time estimation algorithm)

            if ((current_time_ms - open_cmd_time_ms) > OPENING_TIMEOUT_MS)
            {
                io_board->set_press_motor(selected_bottle, IOShield::STOP);
                current_serving_stage = OPEN;
                std::cout << "Hose open after " << open_duration_ms << "ms, halting motor!" << std::endl;
            }
        }
        else if (current_serving_stage == OPEN)
        {
            accumulated_volume += serve_data.volume;

            if (limit_switch_working[selected_bottle] && serve_data.limit_switch) // Sanity check
            {
                std::cout << "Error! We're supposed to be open, but the limit switch is pressed." << std::endl;
                std::cout << "We will now assume the limit switch isn't properly working." << std::endl;
                limit_switch_working[selected_bottle] = false;
            }

            average_flow = updateAverageFlow(measured_flows, serve_data.flow);
        }
        else if (current_serving_stage == CLOSING)
        {
            if ((limit_switch_working[selected_bottle] && serve_data.limit_switch) || ((getTimeMS() - close_cmd_time_ms) > CLOSING_TIMEOUT_MS))
            {
                io_board->set_press_motor(selected_bottle, IOShield::STOP);
                serving = false;
                success = true;

                if (limit_switch_working[selected_bottle])
                {
                    if (serve_data.limit_switch)
                    {
                        std::cout << "Limit switch pressed! Halting motor." << std::endl;
                    }
                    else
                    {
                        std::cout << "The limit switch was not pressed after " << CLOSING_TIMEOUT_MS << "ms, halting motor!" << std::endl;
                        std::cout << "We will now assume the limit switch isn't properly working." << std::endl;
                        limit_switch_working[selected_bottle] = false;
                    }
                }
            }
            else
            {
                accumulated_volume += serve_data.volume;
            }
        }

        if ((current_serving_stage == OPENING) ||  (current_serving_stage == OPEN))
        {
            if (serve_data.flow >= MAXIMUM_FLOW(calibration.whole_pulse_volume))
            {
                std::cout << "The wine flow is too high! We're probably serving nitrogen." << std::endl;
                emergencyCloseFromStage(current_serving_stage);
                serving = false;
                continue;
            }

            // We need to preemptively close the hose, since some wine will still flow after the close command is sent
            if ((volume_mode && (target_volume < (accumulated_volume + average_flow * open_duration_ms + calibration.control_volume_offset)))
                || (!volume_mode && ((current_time_ms - open_cmd_time_ms) > target_time_ms)))
            {
                if (limit_switch_working[selected_bottle] && serve_data.limit_switch) // Sanity check
                {
                    std::cout << "Error! We're supposed to be open, but the limit switch is pressed." << std::endl;
                    std::cout << "We will now assume the limit switch isn't properly working." << std::endl;
                    limit_switch_working[selected_bottle] = false;
                }

                io_board->set_press_motor(selected_bottle, IOShield::FORWARD);
                close_cmd_time_ms = getTimeMS();
                current_serving_stage = CLOSING;

                std::cout << "Closing the hose! We've accumulated " << accumulated_volume << "." << std::endl;

                std::cout << "The maximum measured flow is " << average_flow << " mL/ms." << std::endl;
                if (limit_switch_working[selected_bottle])
                {
                    std::cout << "The motor will halt in " << CLOSING_TIMEOUT_MS << "ms, or upon pressing the limit switch." << std::endl;
                }
                else
                {
                    std::cout << "The motor will halt in " << CLOSING_TIMEOUT_MS << "ms." << std::endl;
                }
            }
        }
    }

    if (volume_mode)
    {
        std::cout << "We tried to serve " << target_volume << "ml";
    }
    else
    {
        std::cout << "We tried to serve for " << target_time_ms << "ms";
    }
    std::cout << " and served " << accumulated_volume << "." << std::endl;

    if (served != NULL)
    {
        *served = accumulated_volume;
    }

    io_board->unlock_updates();

    return success;
}




/*--------------------------------------------------------------------------------------------------------------------------*/
bool WineServer::getLimitSwitchStatus(void){

    serve_data.limit_switch = false;
    updateLimitSwitchStatus();

    return (serve_data.limit_switch);
}
/*--------------------------------------------------------------------------------------------------------------------------*/

long WineServer::getTimeMS(void)
{
    timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return ts.tv_sec * 1000 + ts.tv_nsec / (1000 * 1000);
}

void WineServer::updateLimitSwitchStatus(void)
{
    int true_count = 0;
    int false_count = 0;
    for (int i = 0; i < N_LIMIT_SWITCH_SAMPLES; ++i)
    {
        long query_time_ms = getTimeMS();

        unsigned char data = io_board->non_blocking_get(selected_bottle + n_bottles);

        last_flowmeter_sample = std::make_pair(FLOWMETER_STATUS(data), query_time_ms);

        if (LIMIT_SWITCH_STATUS(data))
        {
            ++true_count;
        }
        else
        {
            ++false_count;
        }
    }

    serve_data.limit_switch = (true_count > false_count) ? true : false;
}

bool WineServer::updateServeData(int timeout_ms)
{
    std::vector<std::pair<bool, long> > flowmeter_states;
    flowmeter_states.reserve(100);
    flowmeter_states.push_back(last_flowmeter_sample);

    serve_data.limit_switch = false;
    bool curr_limit_switch_status = false;
    int curr_limit_swich_count = 0;

    bool initial_state = flowmeter_states[0].first;

    FlowmeterMeasStage current_meas_stage = WAITING_FOR_POLARITY_CHANGE;

    std::pair<bool, long> suspect_polarity_change_data;
    std::pair<bool, long> suspect_pulse_data;
    bool found_pulse = false;

    long start_time_ms = getTimeMS();
    long now;

    bool done = false;
    while (!done && (((now = getTimeMS()) - start_time_ms) < timeout_ms))
    {
        unsigned char data = io_board->non_blocking_get(selected_bottle + n_bottles);

        std::pair<bool, long> new_data = std::make_pair(FLOWMETER_STATUS(data), now);

        bool new_limit_switch_status = LIMIT_SWITCH_STATUS(data);
        if (curr_limit_switch_status == new_limit_switch_status)
        {
            ++curr_limit_swich_count;
            if (curr_limit_swich_count > N_LIMIT_SWITCH_SAMPLES)
            {
                serve_data.limit_switch = curr_limit_switch_status;
            }
        }
        else
        {
            curr_limit_swich_count = 0;
            curr_limit_switch_status = new_limit_switch_status;
        }

        if (serve_data.limit_switch && limit_switch_working[selected_bottle]) // We only skip measuring the flow when the limit switch is on and we trust it
        {
            // The hose is closed, we shouldn't bother trying to measure flow
            done = true;
            serve_data.flow = 0;
            serve_data.volume = 0;

            last_flowmeter_sample = new_data; // This needs to be updated so that we'll measure accurately once the limit switch opens

            continue;
        }

        if (current_meas_stage == WAITING_FOR_POLARITY_CHANGE)
        {
            if (new_data.first != initial_state)
            {
                suspect_polarity_change_data = new_data;
                current_meas_stage = SUSPECTING_POLARITY_CHANGE;
            }
            else
            {
                flowmeter_states.push_back(new_data);
            }
        }
        else if (current_meas_stage == SUSPECTING_POLARITY_CHANGE)
        {
            if (new_data.first != initial_state)
            {
                flowmeter_states.push_back(suspect_polarity_change_data);
                flowmeter_states.push_back(new_data);
                current_meas_stage = WAITING_FOR_PULSE_TO_END;
            }
            else
            {
                current_meas_stage = WAITING_FOR_POLARITY_CHANGE;
                std::cout << "Found fake polarity change." << std::endl;
            }
        }
        else if (current_meas_stage == WAITING_FOR_PULSE_TO_END)
        {
            if (new_data.first == initial_state)
            {
                suspect_pulse_data = new_data;
                current_meas_stage = SUSPECTING_PULSE_HAS_ENDED;
            }
            else
            {
                flowmeter_states.push_back(new_data);
            }
        }
        else if (current_meas_stage == SUSPECTING_PULSE_HAS_ENDED)
        {
            if (new_data.first == initial_state)
            {
                last_flowmeter_sample = suspect_pulse_data; // Ignore the new data, since we only need the first polarity change info
                found_pulse = true;
            }
            else
            {
                current_meas_stage = WAITING_FOR_PULSE_TO_END;
                std::cout << "Found fake pulse end." << std::endl;
            }
        }

        if (found_pulse)
        {
            // Analyse pulse to determine validity/duration
            long first_initial_state_time = flowmeter_states[0].second;
            long last_initial_state_time = 0;
            for (std::vector<std::pair<bool, long> >::iterator fm_it = flowmeter_states.begin(); fm_it != flowmeter_states.end(); ++fm_it)
            {
                if (fm_it->first == initial_state)
                {
                    last_initial_state_time = fm_it->second;
                }
            }

            long first_other_state_time = last_initial_state_time;
            long last_other_state_time = last_flowmeter_sample.second;

            long initial_state_duration_ms = last_initial_state_time - first_initial_state_time;
            long other_state_duration_ms = last_other_state_time - first_other_state_time;

            long pulse_duration_ms = last_other_state_time - first_initial_state_time;

            // Check duty cycle
            if ((initial_state_duration_ms < (0.25 * pulse_duration_ms)) || (initial_state_duration_ms > (0.75 * pulse_duration_ms)))
            {
                std::cout << "Uneven duty cycle!" << std::endl;
            }
            /*
            std::cout << "Pulse: " << pulse_duration_ms << "ms. Data: ";
            for (auto &state : flowmeter_states)
            {
                std::cout << state.first << " ";
            }
            std::cout << std::endl;
            std::cout << "PPMS: " << flowmeter_states.size() / pulse_duration_ms << std::endl;
            */
            serve_data.volume =  calibration.whole_pulse_volume;
            serve_data.flow = serve_data.volume / pulse_duration_ms;

            done = true;
            continue;
        }
    }

    return done;
}

void WineServer::emergencyCloseFromStage(ServingStage currentStage, bool is_emergency)
{
    if (is_emergency)
    {
        std::cout << "Emergency close!" << std::endl;
    }

    if (currentStage == CLOSED)
    {
        std::cout << "Motor already closed, nothing to do." << std::endl;
    }
    else
    {
        // Even if the motor is opening, we can safely move the relays to the forward position,
        // since a short circuit is not possible.

        io_board->set_press_motor(selected_bottle, IOShield::FORWARD);

        long close_cmd_time_ms = getTimeMS();
        std::cout << "Closing press on bottle " << selected_bottle << ", will halt in " << EMERGENCY_CLOSE_TIMEOUT_MS << "ms." << std::endl;

        if (limit_switch_working[selected_bottle])
        {
            std::cout << "The limit switch is working, so we'll stop early if we hit it." << std::endl;
            bool limit_switch;
            long now;
            do
            {
                limit_switch = LIMIT_SWITCH_STATUS(io_board->non_blocking_get(selected_bottle + n_bottles));
                now = getTimeMS();
            }
            while (((now - close_cmd_time_ms) < EMERGENCY_CLOSE_TIMEOUT_MS) && !limit_switch);

            if (!limit_switch)
            {
                std::cout << "We closed the motor, but the limit switch isn't pressed: we're marking it as broken." << std::endl;
                limit_switch_working[selected_bottle] = false;
            }
        }
        else
        {
            std::cout << "The limit switch isn't working, closing blindly!." << std::endl;
            while ((getTimeMS() - close_cmd_time_ms) < EMERGENCY_CLOSE_TIMEOUT_MS)
                ;
        }

        io_board->set_press_motor(selected_bottle, IOShield::STOP);
        std::cout << "Halted motor." << std::endl;
    }

    if (is_emergency)
    {
        std::cout << "Emergency situation resolved." << std::endl;
    }
}

float WineServer::updateAverageFlow(std::list<float> &measured_flows, float new_flow)
{
    measured_flows.push_back(new_flow);
    if (measured_flows.size() > 4)
    {
        measured_flows.pop_front();
    }

    float accumlated_flow = 0;
    for (auto &flow : measured_flows)
    {
        accumlated_flow += flow;
    }
    return accumlated_flow / measured_flows.size();
}