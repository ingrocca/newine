#include "wine_server_config.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <streambuf>
#include <jansson.h>

#define JSON_CONFIG_FILE "/home/newine/newine_client/calibration.json"

WineServerConfig::WineServerConfig(void)
{
    load();
}

void WineServerConfig::load(void)
{
    std::ifstream t(JSON_CONFIG_FILE);
    std::string contents((std::istreambuf_iterator<char>(t)),
                 std::istreambuf_iterator<char>());

    json_error_t error;

    json_t  *root = json_loads(contents.c_str(), 0, &error);
    if (!root)
    {
        std::cout << "WineServerConfig: load error: on line " << error.line << ": " << error.text << std::endl;
        return;
    }

    calibrations.clear();

    json_t *j_calibrations;
    json_unpack(root, "{s:o}", "calibrations", &j_calibrations);

    size_t idx;
    json_t *val;
    json_array_foreach(j_calibrations, idx, val)
    {
        Calibration new_calib;
        new_calib.bottle_index = json_integer_value(json_object_get(val, "bottle_index"));
        new_calib.whole_pulse_volume = json_real_value(json_object_get(val, "whole_pulse_volume"));
        new_calib.control_volume_offset = json_real_value(json_object_get(val, "control_volume_offset"));

        calibrations.push_back(new_calib);
    }

    json_decref(root);
}

void WineServerConfig::save(void)
{
    json_t *root = json_object();
    json_t *json_arr = json_array();

    json_object_set_new(root, "calibrations", json_arr);

    for (auto & calib : calibrations)
    {
        json_t *calib_data = json_object();

        json_object_set_new(calib_data, "bottle_index", json_integer(calib.bottle_index));
        json_object_set_new(calib_data, "whole_pulse_volume", json_real(calib.whole_pulse_volume));
        json_object_set_new(calib_data, "control_volume_offset", json_real(calib.control_volume_offset));

        json_array_append(json_arr, calib_data);
    }

    std::ofstream file(JSON_CONFIG_FILE);
    file << std::string(json_dumps(root, 0));

    json_decref(root);
}

WineServerConfig::Calibration WineServerConfig::get(int index)
{
    for (auto & calib : calibrations)
    {
        if (index == calib.bottle_index)
        {
            return calib;
        }
    }

    // ???
}


void WineServerConfig::set_whole_pulse_volume(int index, int measured, int actual_measure)
{
    if(actual_measure > 0 && measured > 0)
    set_value_whole_pulse_volume(index,measured,actual_measure);
}

void WineServerConfig::reset_whole_pulse_volume(int index)
{
    reset_value_whole_pulse_volume(index);
}

void WineServerConfig::reset_control_volume_offset(int index)
{
    reset_value_control_volume_offset(index);
}

void WineServerConfig::increase_control_volume_offset(int index)
{
    adjust_control_volume_offset(index, 3);
}

void WineServerConfig::decrease_control_volume_offset(int index)
{
    adjust_control_volume_offset(index, -3);
}

void WineServerConfig::set_value_whole_pulse_volume(int index, int measure, int actual_measure)
{
    float adjusted_calib;

    for (auto & calib : calibrations)
    {
        if (index == calib.bottle_index)
        {
            adjusted_calib = ((float)actual_measure / (float)measure) * calib.whole_pulse_volume;
            calib.whole_pulse_volume = adjusted_calib;
            std::cout << "New whole pulse volume: " << adjusted_calib << std::endl;
        }
    }

    save();
}

void WineServerConfig::reset_value_whole_pulse_volume(int index)
{
    for (auto & calib : calibrations)
    {
        if (index == calib.bottle_index)
        {
            calib.whole_pulse_volume = 0.25407;
            std::cout << "Whole pulse volume reset: 0.25407" << std::endl;
        }
    }

    save();
}


void WineServerConfig::adjust_control_volume_offset(int index, float adjustment)
{
    for (auto & calib : calibrations)
    {
        if (index == calib.bottle_index)
        {
            calib.control_volume_offset += adjustment;
            std::cout << "New control volume offset: " << calib.control_volume_offset << std::endl;
        }
    }

    save();
}

void WineServerConfig::reset_value_control_volume_offset(int index)
{
    for (auto & calib : calibrations)
    {
        if (index == calib.bottle_index)
        {
            calib.control_volume_offset = 0;
            std::cout << "Control volume offset reset: 0" << std::endl;
        }
    }

    save();
}