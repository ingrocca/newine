#include "winstar_wg12864a.hpp"
using namespace std;

Winstar_WG12864A::Winstar_WG12864A(void):
    Adafruit_GFX::Adafruit_GFX(WG12864A_WIDTH, WG12864A_HEIGHT)
{

}

void Winstar_WG12864A::initialize(IOShield * brd, unsigned int ind, bool do_turn_on)
{
    board = brd;
    offset = ind;
    fillRect(0, 0, 128, 64, 0); //Clean frame buffer

    if (do_turn_on)
    {
        board->lock_updates();
        board->clear_display_cs(offset,0);  //Protect against display unintentional writes
        board->clear_display_cs(offset,1);
        set_start_line(0);
        turn_off();
        turn_on();
        board->unlock_updates();

        clear_display();
    }
}

void Winstar_WG12864A::turn_on(void)
{
    board->set_display_cs(offset,0);
    board->set_display_cs(offset,1);
    board->clear_display_di(offset);
    board->set_display_data(offset, WG12864A_ON);
    board->non_blocking_flush();
    board->clear_display_cs(offset,0);
    board->clear_display_cs(offset,1);

    std::chrono::milliseconds sl(100);
    std::this_thread::sleep_for(sl);
}

void Winstar_WG12864A::turn_off(void)
{
    board->set_display_cs(offset,0);
    board->set_display_cs(offset,1);
    board->clear_display_di(offset);
    board->set_display_data(offset, WG12864A_OFF);
    board->non_blocking_flush();
    board->clear_display_cs(offset,0);
    board->clear_display_cs(offset,1);

    std::chrono::milliseconds sl(100);
    std::this_thread::sleep_for(sl);
}

void Winstar_WG12864A::set_start_line(char address)
{
    board->set_display_cs(offset,0);
    board->set_display_cs(offset,1);
    board->clear_display_di(offset);
    board->set_display_data(offset, WG12864A_START_LINE | (address & WG12864A_START_LINE_MASK));
    board->non_blocking_flush();
    board->clear_display_cs(offset,0);
    board->clear_display_cs(offset,1);
}

void Winstar_WG12864A::set_page(char x_address)
{
    board->set_display_cs(offset,0);
    board->set_display_cs(offset,1);
    board->clear_display_di(offset);
    board->set_display_data(offset, WG12864A_SET_PAGE | (x_address & WG12864A_SET_PAGE_MASK));
    board->non_blocking_flush();
    board->clear_display_cs(offset,0);
    board->clear_display_cs(offset,1);

}

void Winstar_WG12864A::set_y_address(char y_address)
{
    board->set_display_cs(offset,0);
    board->set_display_cs(offset,1);
    board->clear_display_di(offset);
    board->set_display_data(offset, WG12864A_SET_Y | (y_address & WG12864A_SET_Y_MASK));
    board->non_blocking_flush();
    board->clear_display_cs(offset,0);
    board->clear_display_cs(offset,1);
}

//CAREFULL! write_data is non_blocking.
//write_data loops should be globally locked using
//IOBoard::lock_updates() and IOBoard::unlock_updates()
void Winstar_WG12864A::write_data(char data)
{
    board->set_display_di(offset);
    board->set_display_data(offset, data);
    board->non_blocking_flush();
}

void Winstar_WG12864A::drawPixel(int16_t x, int16_t y, uint16_t color)
{
    if(x>=0 && x<WG12864A_WIDTH && y>=0 && y<WG12864A_HEIGHT)
    {
        if(color > 0)
            fb[x][y/8] |= (1<<(y%8));
        else
            fb[x][y/8] &= ~(1<<(y%8));
    }
}

void Winstar_WG12864A::update_display(void)
{
    board->lock_updates();

    set_start_line(0); // This instruction might be incorrectly issued due to EMI - this fixes vertical screen tearing
    for(int page=0; page<WG12864A_HEIGHT/8; page++)
    {
        set_page(page);
        set_y_address(0);   //after writing The Y address is increased by 1 automatically.
        board->set_display_cs(offset,1);
        board->clear_display_cs(offset,0);
        for(int y=0; y<WG12864A_WIDTH/2; y++)
        {
            write_data(fb[y][page]);
        }
        board->clear_display_cs(offset,1);
        board->set_display_cs(offset,0);
        for(int y=WG12864A_WIDTH/2; y<WG12864A_WIDTH; y++)
        {
            write_data(fb[y][page]);
        }

    }

    board->clear_display_cs(offset,0);
    board->clear_display_cs(offset,1);
    board -> non_blocking_flush();
    board->unlock_updates();
}

void Winstar_WG12864A::clear_display(void)
{
    board->lock_updates();
    board->set_display_cs(offset,0);    //Set CS0 & CS1 to write simultaneously
    board->set_display_cs(offset,1);    //in columns (0~63) and (64~127)

    set_start_line(0); // This instruction might be incorrectly issued due to EMI - this fixes vertical screen tearing
    for(int page=0; page<WG12864A_HEIGHT/8; page++)
    {
        set_page(page);
        set_y_address(0);
        for(int y=0; y<WG12864A_WIDTH/2; y++)
        {
            fb[y][page] = 0;
            fb[y+WG12864A_WIDTH/2][page] = 0;
            write_data(0);
        }
    }
    board->clear_display_cs(offset,0);
    board->clear_display_cs(offset,1);
    board -> non_blocking_flush();
    board->unlock_updates();
}
